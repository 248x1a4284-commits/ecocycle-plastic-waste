import React, { useState, useEffect } from 'react';
import { 
  Recycle, 
  Menu, 
  X, 
  Sparkles, 
  Calculator, 
  MapPin, 
  CheckCircle2, 
  Activity,
  Compass,
  Lightbulb,
  ShieldAlert
} from 'lucide-react';

export default function Navbar({ completedChallengesCount = 0, onNavigate }) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Pollution Crisis', href: '#awareness', icon: ShieldAlert },
    { label: 'Smart Tech', href: '#solutions', icon: Lightbulb },
    { label: 'Calculator', href: '#calculator', icon: Calculator },
    { label: 'Sorting Guide', href: '#guide', icon: Compass },
    { label: '7-Day Challenge', href: '#challenge', icon: CheckCircle2, badge: `${completedChallengesCount}/7` },
    { label: 'Locator', href: '#locator', icon: MapPin },
    { label: 'Dashboard', href: '#dashboard', icon: Activity },
    { label: 'Take Action', href: '#action', icon: Sparkles },
  ];

  const handleLinkClick = (e, href) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      const navOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - navOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled 
        ? 'bg-white/90 backdrop-blur-md shadow-sm border-b border-emerald-100/60 py-3' 
        : 'bg-white/70 backdrop-blur-sm py-4'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          
          {/* Logo & Brand */}
          <a 
            href="#hero" 
            onClick={(e) => handleLinkClick(e, '#hero')}
            className="flex items-center gap-2.5 group cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 via-teal-500 to-sky-500 flex items-center justify-center text-white shadow-md shadow-emerald-600/20 group-hover:scale-105 transition-transform duration-200">
              <Recycle className="w-5 h-5 transition-transform group-hover:rotate-45 duration-500" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-xl tracking-tight text-emerald-950 font-serif sm:font-sans">EcoCycle</span>
                <span className="text-[10px] font-semibold uppercase tracking-wider bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded-full border border-emerald-200">
                  Smart Tech
                </span>
              </div>
              <p className="text-[11px] text-emerald-700/80 hidden sm:block -mt-0.5 font-medium">
                Plastic Waste Management Platform
              </p>
            </div>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navLinks.map((link) => {
              const Icon = link.icon;
              return (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={(e) => handleLinkClick(e, link.href)}
                  className="flex items-center gap-1.5 px-3 py-2 text-xs xl:text-sm font-medium text-slate-700 hover:text-emerald-700 hover:bg-emerald-50/80 rounded-lg transition-colors relative group"
                >
                  <Icon className="w-3.5 h-3.5 text-slate-400 group-hover:text-emerald-600 transition-colors" />
                  <span>{link.label}</span>
                  {link.badge && (
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded-full border border-emerald-300">
                      {link.badge}
                    </span>
                  )}
                </a>
              );
            })}
          </nav>

          {/* Right Action Button */}
          <div className="hidden sm:flex items-center gap-3">
            <a
              href="#calculator"
              onClick={(e) => handleLinkClick(e, '#calculator')}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white shadow-md shadow-emerald-700/20 hover:shadow-lg hover:shadow-emerald-700/30 transition-all transform hover:-translate-y-0.5 active:translate-y-0"
            >
              <Calculator className="w-3.5 h-3.5" />
              <span>Calculate Footprint</span>
            </a>
          </div>

          {/* Mobile Hamburger Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-xl text-slate-700 hover:text-emerald-700 hover:bg-emerald-50 focus:outline-none transition-colors"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white/95 backdrop-blur-xl border-b border-emerald-100 px-4 pt-3 pb-6 shadow-xl animate-in fade-in slide-in-from-top-4 duration-200">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 mb-4">
            {navLinks.map((link) => {
              const Icon = link.icon;
              return (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={(e) => handleLinkClick(e, link.href)}
                  className="flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-emerald-50 hover:text-emerald-800 transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className="w-4 h-4 text-emerald-600" />
                    <span>{link.label}</span>
                  </div>
                  {link.badge && (
                    <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
                      {link.badge}
                    </span>
                  )}
                </a>
              );
            })}
          </div>
          <div className="pt-2 border-t border-slate-100">
            <a
              href="#calculator"
              onClick={(e) => handleLinkClick(e, '#calculator')}
              className="flex items-center justify-center gap-2 w-full py-2.5 text-sm font-semibold rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-700/20"
            >
              <Calculator className="w-4 h-4" />
              <span>Calculate My Plastic Footprint</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
