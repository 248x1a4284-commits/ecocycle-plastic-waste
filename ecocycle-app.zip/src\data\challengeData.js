// 7-Day Plastic-Free Challenge Data
export const challengeDays = [
  {
    day: 1,
    title: 'Carry a Reusable Water Bottle',
    badge: 'Hydration Habit',
    icon: 'Droplets',
    action: 'Refuse single-use bottled water all day. Fill up a stainless steel, glass, or durable BPA-free water bottle before heading out.',
    impactTip: 'Saves an average of 3 to 4 single-use PET bottles per person, avoiding ~300g of fossil CO2 emissions.',
    proTip: 'Look for municipal or campus hydration refill stations using apps like Tap or Refill.'
  },
  {
    day: 2,
    title: 'Avoid Single-Use Plastic Bags',
    badge: 'Zero Bag Waste',
    icon: 'ShoppingBag',
    action: 'Say "No bag, thank you" for quick purchases, or carry loose goods by hand if you forgot your bag.',
    impactTip: 'The average plastic bag is used for just 12 minutes but takes up to 500 years to photo-degrade.',
    proTip: 'Keep a foldable compact tote clipped onto your daily backpack or keychain so you are never caught unprepared.'
  },
  {
    day: 3,
    title: 'Bring Reusable Shopping & Produce Bags',
    badge: 'Smart Groceries',
    icon: 'PackageCheck',
    action: 'Do a full grocery or market run using only canvas totes and reusable mesh bags for loose fruits and vegetables.',
    impactTip: 'Eliminates thin plastic produce roll bags which are almost impossible to recycle curbside.',
    proTip: 'Place apples, bananas, and citrus directly in your basket without any plastic bag at all—they already have natural protective skins!'
  },
  {
    day: 4,
    title: 'Refuse Unnecessary Plastic Straws & Cutlery',
    badge: 'Conscious Dining',
    icon: 'Coffee',
    action: 'Order drinks with "No straw please" and decline disposable forks, spoons, and napkins when ordering takeout meals.',
    impactTip: 'Over 500 million plastic straws are discarded daily in North America alone, frequently ending up in marine waterways.',
    proTip: 'Keep a compact bamboo or stainless steel travel fork/spoon set in your work or study bag.'
  },
  {
    day: 5,
    title: 'Segregate Plastic Waste at Home',
    badge: 'Source Segregation',
    icon: 'Boxes',
    action: 'Set up a dedicated two-bin system at home: one for wet organic waste, and one for clean, rinsed, dry plastics.',
    impactTip: 'Clean source segregation increases the likelihood of plastic being successfully recycled from 10% to over 85%.',
    proTip: 'Always rinse food residue and grease from containers before tossing them into the plastic bin.'
  },
  {
    day: 6,
    title: 'Reuse Suitable Plastic Containers Safely',
    badge: 'Safe Upcycling',
    icon: 'Repeat',
    action: 'Upcycle food-safe rigid plastic tubs (like PP #5 or HDPE #2) for organizing hardware, seed planting, or dry pantry storage.',
    impactTip: 'Extending the lifespan of existing plastic goods delays new plastic manufacture and cuts down on virgin resin demand.',
    proTip: 'Never microwave food in single-use takeout plastics or #7 plastics, as heat accelerates chemical additive leaching.'
  },
  {
    day: 7,
    title: 'Find a Local Recycling Collection Point',
    badge: 'Closed-Loop Champion',
    icon: 'MapPin',
    action: 'Locate a verified municipal recycling depot, supermarket film return bin, or e-waste drop-off and take your segregated recyclables.',
    impactTip: 'Ensures hard-to-recycle films and clean rigid polymers make it directly to certified recovery facilities.',
    proTip: 'Check operating hours and accepted resin codes before heading out, or use the EcoCycle Recycling Locator.'
  }
];
