// Comprehensive waste sorting items database
export const sortingCategories = [
  { id: 'all', label: 'All Items' },
  { id: 'recyclable', label: 'Curbside Recyclable' },
  { id: 'special', label: 'Special Drop-Off Required' },
  { id: 'landfill', label: 'Non-Recyclable / Trash' },
  { id: 'compost', label: 'Industrial Compostable' }
];

export const sortingItems = [
  {
    id: 'pet-bottle',
    name: 'Plastic Beverage / Water Bottle',
    resinCode: '#1 PET (Polyethylene Terephthalate)',
    category: 'recyclable',
    categoryLabel: 'Commonly Recyclable',
    badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    preparation: [
      'Empty all liquid completely to prevent contaminating paper in the truck',
      'Quickly rinse with leftover greywater to remove sweet residue',
      'Crush or flatten bottle to save bin volume',
      'Screw cap back on firmly (modern sorting facilities prefer caps on to prevent them jamming screens)'
    ],
    commonMistakes: 'Leaving bottle half-full of liquid; throwing away without cap in cities requiring caps-on.',
    notes: 'One of the most valuable and commonly recycled plastic resins worldwide. Converted into new bottles, polyester textiles, and strap bands.'
  },
  {
    id: 'milk-jug',
    name: 'Milk Jug & Heavy Detergent Bottle',
    resinCode: '#2 HDPE (High-Density Polyethylene)',
    category: 'recyclable',
    categoryLabel: 'Commonly Recyclable',
    badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    preparation: [
      'Thoroughly rinse out milk curd or thick laundry soap residue',
      'Do not flatten excessively if rigid; let it air dry',
      'Keep cap screwed on or follow your local hauler preference'
    ],
    commonMistakes: 'Discarding with oily or greasy pesticide/motor oil chemical residue (motor oil bottles are hazardous waste and cannot go into curbside bins).',
    notes: 'Very high recycling demand. Typically recycled into sturdy outdoor furniture, drainage pipes, plastic lumber, and new detergent jugs.'
  },
  {
    id: 'food-wrapper',
    name: 'Chip Bag, Candy & Snack Wrappers',
    resinCode: '#7 Other (Multilayer Metallized Film: BOPP + Aluminum + PE)',
    category: 'landfill',
    categoryLabel: 'Non-Recyclable (Landfill)',
    badgeColor: 'bg-rose-100 text-rose-800 border-rose-300',
    preparation: [
      'Do NOT place in your curbside recycling bin—it cannot be mechanically separated',
      'Dispose in non-recyclable landfill or municipal waste-to-energy bin',
      'Wipe clean if participating in dedicated mail-back programs (e.g. TerraCycle)'
    ],
    commonMistakes: 'Wishcycling: assuming shiny foil wrapper is aluminum foil. The fused plastic and metal layers cannot be separated by standard MRFs.',
    notes: 'Complex multi-layer structure prevents conventional recycling. Support brands shifting to mono-material or certified compostable barriers.'
  },
  {
    id: 'grocery-bag',
    name: 'Thin Plastic Grocery Bag & Bubble Wrap',
    resinCode: '#4 LDPE (Low-Density Polyethylene Film)',
    category: 'special',
    categoryLabel: 'Special Store Drop-Off Only',
    badgeColor: 'bg-amber-100 text-amber-800 border-amber-300',
    preparation: [
      'NEVER put loose in your standard curbside recycling bin',
      'Plastic bags tangle and shut down mechanical sorting machine rotors, endangering workers',
      'Ensure completely clean, dry, and free of food scraps or receipts',
      'Bundle clean bags into one bag and take to supermarket plastic film drop-off collection bins'
    ],
    commonMistakes: 'Bagging your curbside recyclables inside a plastic bag (workers often toss entire tied bags into trash due to safety regulations).',
    notes: 'Clean polyethylene stretch film is remelted into composite decking (like Trex) and new plastic shipping envelopes when dropped off at dedicated retail bins.'
  },
  {
    id: 'takeaway-container',
    name: 'Rigid Takeaway Food Container & Yogurt Tub',
    resinCode: '#5 PP (Polypropylene)',
    category: 'recyclable',
    categoryLabel: 'Commonly Recyclable (Check Local Rules)',
    badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    preparation: [
      'Scrape all remaining food scraps and gravy thoroughly into compost/food waste',
      'Rinse with warm soapy water until free of visible grease film',
      'Dry before placing into your plastic recycling bin'
    ],
    commonMistakes: 'Leaving cheese, sauce, or greasy napkins inside, which degrades entire batches of recycled plastic pellets.',
    notes: 'Accepted in majority of modern curbside programs. Recycled into car battery casings, bins, paint cans, and storage boxes.'
  },
  {
    id: 'styrofoam-clamshell',
    name: 'Styrofoam Takeout Box & Foam Cup',
    resinCode: '#6 PS (Expanded Polystyrene / EPS)',
    category: 'landfill',
    categoryLabel: 'Non-Recyclable Curbside (Landfill)',
    badgeColor: 'bg-rose-100 text-rose-800 border-rose-300',
    preparation: [
      'Curbside recyclers reject expanded polystyrene because it is 95% air and breaks into millions of static micro-beads',
      'Place in regular trash unless your municipality has a specialized EPS densifier depot',
      'Wipe clean if transporting to a designated foam densification drop-off facility'
    ],
    commonMistakes: 'Putting white foam clamshells in blue recycling bins where they crumble into micro-fragments that contaminate other recyclables.',
    notes: 'Economically prohibitive for haulers to transport due to low density. Banned in many progressive cities in favor of fiber-based alternatives.'
  },
  {
    id: 'disposable-coffee-cup',
    name: 'Paper Coffee Cup with Plastic Polyethylene Lining',
    resinCode: 'Mixed Paper + Thin PE Plastic Coating',
    category: 'landfill',
    categoryLabel: 'Non-Recyclable Curbside',
    badgeColor: 'bg-rose-100 text-rose-800 border-rose-300',
    preparation: [
      'Separate the plastic lid (usually #5 or #6): check lid code for recycling',
      'Remove cardboard heat sleeve (100% recyclable paper)',
      'The cup itself goes into general trash in most cities because the water-resistant plastic barrier cannot be pulped by standard paper mills'
    ],
    commonMistakes: 'Tossing whole coffee cup into paper or plastic bins. Standard paper hydropulpers cannot dissolve the plastic waterproofing lining.',
    notes: 'Over 16 billion paper cups are thrown out each year. Carry a collapsible reusable thermos or stainless mug to save hundreds of cups.'
  },
  {
    id: 'plastic-cutlery',
    name: 'Disposable Plastic Forks, Spoons & Knives',
    resinCode: '#6 PS or #5 PP',
    category: 'landfill',
    categoryLabel: 'Non-Recyclable / Trash',
    badgeColor: 'bg-rose-100 text-rose-800 border-rose-300',
    preparation: [
      'Even if stamped with a recycling triangle, single-use cutlery is too thin and small for MRF sorting screens',
      'Cutlery falls through mechanical trommel screens into residue glass/trash',
      'Dispose in regular waste bin'
    ],
    commonMistakes: 'Assuming the triangular chasing arrows symbol means curbside facilities accept it.',
    notes: 'Always decline disposable cutlery when ordering takeout food at home or office. Keep a portable utensil set in your bag.'
  },
  {
    id: 'toothpaste-tube',
    name: 'Squeezable Toothpaste & Lotion Tube',
    resinCode: 'Multilayer Aluminum-Plastic Laminate (or new HDPE)',
    category: 'special',
    categoryLabel: 'Check Tube Label / Special Drop-Off',
    badgeColor: 'bg-amber-100 text-amber-800 border-amber-300',
    preparation: [
      'Look for the "#2 HDPE Recyclable" mark on newer redesigned tubes (like Colgate/Tom’s)',
      'If not marked HDPE, dispose in trash as it contains interior aluminum foils',
      'Squeeze out as much toothpaste as physically possible; rinse if you slice it open'
    ],
    commonMistakes: 'Putting unverified older tubes into recycling bins without verifying HDPE certification.',
    notes: 'Industry is actively transitioning toward 100% monomaterial HDPE tubes that can be recycled with milk jugs once fully emptied.'
  },
  {
    id: 'bioplastic-cup',
    name: 'Compostable "Green" Bioplastic Cup / Clamshell',
    resinCode: '#7 PLA (Polylactic Acid)',
    category: 'compost',
    categoryLabel: 'Industrial Composting Only',
    badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    preparation: [
      'Do NOT put in curbside plastic recycling—it melts at different temperatures and ruins PET recycling batches',
      'Place in designated commercial food waste/organics bin if your city accepts certified compostable plastics (BPI or EN 13432 certified)',
      'If no industrial composting is accessible, place in landfill trash'
    ],
    commonMistakes: 'Throwing PLA cups into backyard compost piles where they will persist for decades due to lack of 60°C sustained thermophilic heat.',
    notes: 'Bioplastics solve fossil fuel extraction concerns but require dedicated composting infrastructure to deliver environmental benefits.'
  },
  {
    id: 'shampoo-bottle',
    name: 'Shampoo & Conditioner Bottles',
    resinCode: '#2 HDPE or #1 PET',
    category: 'recyclable',
    categoryLabel: 'Commonly Recyclable',
    badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    preparation: [
      'Rinse out soapy residues with bathroom water',
      'Remove pump mechanisms (pumps contain metal internal springs and mixed polymers, so throw pump in trash)',
      'Standard screw caps can remain on the bottle'
    ],
    commonMistakes: 'Leaving pump dispensers attached to recyclable bottles. The steel spring inside jams shredder blades.',
    notes: 'Bathroom plastics are recycled at significantly lower rates than kitchen plastics. Keep a small recycling bin in your bathroom.'
  },
  {
    id: 'bubble-mailer',
    name: 'Padded Plastic Bubble Shipping Mailer',
    resinCode: '#4 LDPE Film or Mixed Paper/Bubble',
    category: 'special',
    categoryLabel: 'Store Drop-Off (If All-Plastic)',
    badgeColor: 'bg-amber-100 text-amber-800 border-amber-300',
    preparation: [
      'If all-plastic (look for "Store Drop-Off" How2Recycle logo), peel off paper shipping label if possible',
      'Take to supermarket plastic film drop-off bin with grocery bags',
      'If mailer is paper exterior with plastic bubble glued inside, it cannot be recycled and must go into trash'
    ],
    commonMistakes: 'Putting padded paper-bubble envelopes in paper recycling; the fused plastic adhesive contaminates paper pulp.',
    notes: 'E-commerce shipping generates billions of mailers yearly. Look for 100% curbside recyclable padded paper envelopes.'
  }
];
