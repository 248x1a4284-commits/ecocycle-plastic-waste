import React, { useState } from 'react';
import { 
  Search, 
  Compass, 
  CheckCircle2, 
  AlertTriangle, 
  Info, 
  HelpCircle, 
  Sparkles,
  ArrowRight,
  Filter
} from 'lucide-react';
import { sortingItems, sortingCategories } from '../data/sortingItems';

export default function WasteSortingGuide() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedItem, setSelectedItem] = useState(null);

  // Filter items
  const filteredItems = sortingItems.filter((item) => {
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesSearch = 
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.resinCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.categoryLabel.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.notes.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const popularSearches = [
    'Plastic Bottle',
    'Chip Bag',
    'Takeaway Container',
    'Plastic Grocery Bag',
    'Styrofoam',
    'Coffee Cup'
  ];

  return (
    <section id="guide" className="py-20 bg-slate-50 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wider mb-3">
            <Compass className="w-3.5 h-3.5 text-emerald-600" />
            <span>Smart Segregation Directory</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Interactive Plastic Waste Sorting Guide
          </h2>
          <p className="mt-3 text-base text-slate-600 leading-relaxed">
            Search any household plastic item to check its resin category, necessary preparation steps, 
            and actual recyclability. Avoid "wishcycling" that contaminates whole truckloads.
          </p>
        </div>

        {/* Search & Filter Toolbar */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-200/80 mb-10">
          
          {/* Main Search Input */}
          <div className="relative mb-6">
            <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by item name, material, or resin code (e.g. bottle, wrapper, styrofoam, #5 PP)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3.5 rounded-2xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white text-sm text-slate-900 placeholder:text-slate-400 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-semibold text-slate-400 hover:text-slate-600 px-2 py-1 bg-slate-200/60 rounded-md"
              >
                Clear
              </button>
            )}
          </div>

          {/* Quick Search Chips */}
          <div className="flex flex-wrap items-center gap-2 mb-6">
            <span className="text-xs font-semibold text-slate-500 mr-1 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              Popular:
            </span>
            {popularSearches.map((chip) => (
              <button
                key={chip}
                onClick={() => setSearchQuery(chip)}
                className="text-xs font-medium px-3 py-1 rounded-lg bg-slate-100 hover:bg-emerald-50 hover:text-emerald-800 text-slate-600 border border-slate-200 transition-colors cursor-pointer"
              >
                {chip}
              </button>
            ))}
          </div>

          {/* Category Filter Pills */}
          <div className="flex flex-wrap items-center gap-2 pt-4 border-t border-slate-100">
            <span className="text-xs font-bold text-slate-400 mr-2 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Filter Category:
            </span>
            {sortingCategories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

        </div>

        {/* Universal Disclaimer Alert as Required */}
        <div className="mb-8 p-4 rounded-2xl bg-sky-50 border border-sky-200 text-sky-950 text-xs flex items-start gap-3 text-left">
          <Info className="w-5 h-5 text-sky-600 shrink-0 mt-0.5" />
          <div>
            <strong>Important Municipal Reminder:</strong> Recycling capabilities vary significantly by region, city, 
            and sorting contractor. An item marked recyclable may not be accepted in every municipal blue bin. 
            Always cross-reference with your specific local government or municipal waste hauler guidelines.
          </div>
        </div>

        {/* Results Grid */}
        {filteredItems.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-slate-200">
            <HelpCircle className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h4 className="text-base font-bold text-slate-800">No items matched your search</h4>
            <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
              Try searching for common generic terms like "bottle", "jug", "cup", "wrapper", or resin codes like "#1" or "#5".
            </p>
            <button
              onClick={() => { setSearchQuery(''); setSelectedCategory('all'); }}
              className="mt-4 px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 transition-colors"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                className="bg-white rounded-3xl p-6 border border-slate-200/80 hover:border-emerald-300 hover:shadow-xl transition-all duration-300 flex flex-col justify-between text-left"
              >
                <div>
                  {/* Category Status Badge */}
                  <div className="flex items-center justify-between mb-3">
                    <span className={`text-[11px] font-bold px-3 py-1 rounded-full border ${item.badgeColor}`}>
                      {item.categoryLabel}
                    </span>
                    <span className="text-[11px] font-mono text-slate-500 font-semibold bg-slate-100 px-2 py-0.5 rounded">
                      {item.resinCode.split(' ')[0]}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 leading-snug">
                    {item.name}
                  </h3>
                  
                  <p className="text-xs text-slate-500 font-mono mt-0.5">
                    {item.resinCode}
                  </p>

                  {/* Preparation Checklist */}
                  <div className="mt-4 pt-3 border-t border-slate-100">
                    <h5 className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                      Required Preparation:
                    </h5>
                    <ul className="space-y-1.5">
                      {item.preparation.map((step, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-xs text-slate-700">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{step}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Common Mistake Callout */}
                  <div className="mt-4 p-3 rounded-xl bg-amber-50/70 border border-amber-200/60 text-[11px] text-amber-900">
                    <div className="flex items-center gap-1 font-bold text-amber-800 mb-0.5">
                      <AlertTriangle className="w-3 h-3 text-amber-600" />
                      <span>Watch Out (Wishcycling):</span>
                    </div>
                    {item.commonMistakes}
                  </div>
                </div>

                {/* Practical Notes */}
                <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] text-slate-500 italic">
                  💡 {item.notes}
                </div>

              </div>
            ))}
          </div>
        )}

      </div>
    </section>
  );
}
