// Data for Smart Recycling Solutions with realistic technical nuance
export const smartSolutions = [
  {
    id: 'ai-identification',
    title: 'AI-Powered Computer Vision & Spectral Identification',
    category: 'Sensing & Classification',
    icon: 'Cpu',
    tag: 'Artificial Intelligence',
    tagColor: 'bg-emerald-100 text-emerald-800',
    summary: 'High-speed optical cameras combined with deep learning convolutional neural networks detect and classify polymer grades in milliseconds.',
    howItWorks: 'Recycling streams pass under hyper-spectral cameras and RGB image sensors on high-speed conveyor belts. The AI model analyzes optical reflectance, shape, transparency, brand branding, and resin identifiers, differentiating food-grade PET from non-food PET at over 120 items per minute.',
    benefits: [
      'Increases identification accuracy to >95% even when containers are crushed or dirty',
      'Provides real-time analytics on waste composition for municipal facilities',
      'Detects hazardous materials or black plastics normally missed by standard optics'
    ],
    limitations: [
      'High upfront capital expenditure for high-definition spectral sensors',
      'Severely contaminated, blackened, or multilayer items can still confuse optical algorithms',
      'Requires continuous retraining on new packaging designs and regional packaging variants'
    ],
    stats: {
      speed: 'Up to 3,000 items/min',
      accuracy: '96–99%',
      adoptionRate: 'Growing rapidly across modern MRFs (Material Recovery Facilities)'
    }
  },
  {
    id: 'robotic-sorting',
    title: 'Recycling Robotics & Automated High-Speed Sorting',
    category: 'Automation & Robotics',
    icon: 'Bot',
    tag: 'Autonomous Robotics',
    tagColor: 'bg-cyan-100 text-cyan-800',
    summary: 'Delta and SCARA robotic arms equipped with pneumatic suction grips autonomously extract recyclable polymers from mixed waste belts.',
    howItWorks: 'Synchronized with AI vision systems, robotic manipulators track the coordinates of moving items on conveyor belts. Using high-pressure pneumatic suction cups or mechanical grippers, the robots pick target plastics (e.g. HDPE jugs, PET bottles) and deposit them into designated sorting chutes continuously 24/7.',
    benefits: [
      'Executes up to 80 picks per minute—more than double the rate of manual human sorters',
      'Reduces worker exposure to hazardous medical, sharp, or bio-waste on conveyor lines',
      'Maintains consistent pick rates without fatigue over long operating shifts'
    ],
    limitations: [
      'Limited payload capacity; heavy or irregularly snagged items can cause grip drops',
      'Robotics cannot physically untangle entwined plastic films or long cords',
      'Requires substantial floor space and structural retrofitting in legacy recycling plants'
    ],
    stats: {
      speed: '60–80 picks per minute',
      operatingHours: '24/7 continuous operation',
      purityRate: 'Over 95% clean fraction sorting'
    }
  },
  {
    id: 'smart-segregation',
    title: 'Optical Near-Infrared (NIR) Air-Jet Sorting Systems',
    category: 'Pneumatic Sorting',
    icon: 'Zap',
    tag: 'Advanced Optics & Air Ejection',
    tagColor: 'bg-blue-100 text-blue-800',
    summary: 'Near-Infrared spectrometry identifies polymer signatures while precision air-jet valves deflect target resins into separate bins.',
    howItWorks: 'Waste moves across an acceleration conveyor at speeds up to 3 meters per second. NIR sensors illuminate items and read their infrared absorption spectrum to identify resin chemistry (PET, HDPE, PP, PS). High-speed pneumatic air nozzles positioned downstream blast millisecond air jets to physically propel specific plastics into separation hoppers.',
    benefits: [
      'Handles massive throughputs of up to 10 tons of mixed waste per hour',
      'Can separate transparent PET from colored PET for high-value bottle-to-bottle recycling',
      'Industry benchmark for high-volume municipal material recovery facilities (MRFs)'
    ],
    limitations: [
      'Carbon black pigmented plastics absorb NIR light, making detection impossible without specialized Mid-IR sensors',
      'Thin multi-layer films often mask underlying polymers',
      'Consumes significant compressed air energy'
    ],
    stats: {
      throughput: '5–10 tons per hour',
      separationPurity: 'Up to 98%',
      airNozzleLatency: '< 5 milliseconds'
    }
  },
  {
    id: 'plastic-to-materials',
    title: 'Advanced Depolymerization & Upcycled Construction Materials',
    category: 'Material Conversion & Pyrolysis',
    icon: 'Hammer',
    tag: 'Chemical & Structural Upcycling',
    tagColor: 'bg-amber-100 text-amber-800',
    summary: 'Thermochemical depolymerization and structural composite compression converting difficult non-recyclable plastics into durable building blocks or monomers.',
    howItWorks: 'Non-recyclable films (#3, #4, #7) and mixed plastics are shredded and either: 1) Combined with sand/aggregates under heat and hydraulic pressure to produce structural eco-pavers, roofing tiles, and asphalt additives, or 2) Subjected to thermal pyrolysis/glycolysis breakdown into base hydrocarbons or monomer feedstocks in oxygen-deprived reactors.',
    benefits: [
      'Diverts hard-to-recycle multi-layer packaging from immediate landfill burial',
      'Eco-bricks and plastic-bitumen roads show high water resistance and durability',
      'Can process mixed low-grade plastics that mechanical recyclers reject'
    ],
    limitations: [
      'Crucial Nuance: Plastic-to-fuel is NOT circular recycling; it is a thermal recovery step that releases CO2 when burned and creates fossil fuel consumption',
      'Pyrolysis reactors are energy-intensive, produce toxic char/sludge, and can emit greenhouse gases',
      'Long-term leaching of microplastics and plasticizers from recycled building materials requires ongoing environmental monitoring'
    ],
    stats: {
      diversion: 'Captures low-grade #3-#7 plastics',
      brickStrength: '15–20% higher tensile strength than standard clay bricks',
      importantNote: 'Energy-intensive; priority should remain reduction and reuse'
    }
  },
  {
    id: 'digital-tracking',
    title: 'Smart Reverse Vending & IoT Waste Tracking Applications',
    category: 'Digital Infrastructure',
    icon: 'Smartphone',
    tag: 'IoT & Deposit Return Schemes (DRS)',
    tagColor: 'bg-purple-100 text-purple-800',
    summary: 'Connected Reverse Vending Machines (RVMs) and digital deposit return schemes reward consumers while creating transparent traceability.',
    howItWorks: 'Consumers deposit used beverage bottles or cans into automated kiosk RVMs. Barcode scanners verify the container deposit registry, compact the bottle instantly to save bin volume, and credit the user with mobile refunds, coupons, or eco-points via mobile app. IoT telematics notify municipal haulers when bins reach capacity.',
    benefits: [
      'Achieves bottle return rates exceeding 90% in countries with Deposit Return Schemes (e.g. Germany, Norway)',
      'Delivers an unmixed, hyper-clean PET stream completely free from organic food contamination',
      'Directly engages consumers with immediate financial rewards or community green points'
    ],
    limitations: [
      'Requires substantial municipal policy support, legislation, and bottle manufacturer coordination',
      'Kiosk units require continuous maintenance, anti-vandalism design, and periodic emptying',
      'Only targets uniform beverage packaging, leaving films and sachets unaddressed'
    ],
    stats: {
      returnRates: '92–98% in active DRS countries',
      purity: 'Highest purity PET feedstock available for food-grade reuse',
      networkScale: '100,000+ RVMs worldwide'
    }
  },
  {
    id: 'circular-economy',
    title: 'Closed-Loop Bottle-to-Bottle & Refill Systems',
    category: 'Systemic Design',
    icon: 'Repeat',
    tag: 'True Circular Economy',
    tagColor: 'bg-emerald-100 text-emerald-800',
    summary: 'Systemic models that eliminate downcycling by retaining plastics at their highest economic and chemical quality across repeated lifecycles.',
    howItWorks: 'Instead of downcycling clear bottles into synthetic polyester carpet or fleece that ends in landfill, closed-loop recycling cleans, melts, and solid-state polycondenses PET flakes back into certified food-contact resin. Simultaneously, reusable container infrastructure replaces single-use shampoo, detergent, and pantry packaging with returnable, standardized vessels.',
    benefits: [
      'Drastically curbs demand for virgin fossil-based polymer synthesis',
      'Lowers product carbon footprints by up to 60% compared to virgin petrochemical resins',
      'Promotes product redesign, standardization, and elimination of non-essential packaging'
    ],
    limitations: [
      'Even closed-loop PET degrades over 5 to 7 mechanical cycles, requiring virgin resin makeup or chemical recycling',
      'Refill distribution networks require localized washing hubs and reverse logistics infrastructure',
      'Consumer habit change and corporate packaging standardization remain significant friction points'
    ],
    stats: {
      energySaving: '67–75% lower energy than virgin PET production',
      cycleCap: '5–7 cycles mechanically before polymer chain shortening',
      target: '50%+ recycled content mandated in leading sustainability standards'
    }
  }
];
