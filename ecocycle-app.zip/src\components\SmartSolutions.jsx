import React, { useState } from 'react';
import { 
  Cpu, 
  Bot, 
  Zap, 
  Hammer, 
  Smartphone, 
  Repeat, 
  CheckCircle2, 
  AlertCircle, 
  ArrowUpRight, 
  X, 
  Sparkles,
  ShieldAlert
} from 'lucide-react';
import { smartSolutions } from '../data/smartSolutionsData';

export default function SmartSolutions() {
  const [selectedSolution, setSelectedSolution] = useState(null);
  const [activeCategory, setActiveCategory] = useState('All');

  const iconMap = {
    Cpu,
    Bot,
    Zap,
    Hammer,
    Smartphone,
    Repeat
  };

  const categories = ['All', 'Sensing & Classification', 'Automation & Robotics', 'Pneumatic Sorting', 'Material Conversion & Pyrolysis', 'Digital Infrastructure', 'Systemic Design'];

  const filteredSolutions = activeCategory === 'All' 
    ? smartSolutions 
    : smartSolutions.filter(s => s.category === activeCategory);

  return (
    <section id="solutions" className="py-20 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>Technological Innovations</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Smart Recycling Solutions & Clean Tech
          </h2>
          <p className="mt-3 text-base text-slate-600 leading-relaxed">
            Harnessing computer vision, robotics, smart sensor grids, and circular chemistry to optimize recovery 
            while transparently recognizing real-world thermodynamic and economic limits.
          </p>

          {/* Critical Nuance Banner */}
          <div className="mt-4 p-3.5 bg-amber-50/80 rounded-2xl border border-amber-200/80 text-left flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
            <p className="text-xs text-amber-900 leading-relaxed">
              <strong>Scientific Transparency:</strong> Not all plastics can be infinitely or easily recycled. 
              Technologies like pyrolysis (plastic-to-fuel) represent thermal energy recovery rather than closed-loop circular recycling. 
              True sustainability begins with systematic reduction, reusable formats, and redesign.
            </p>
          </div>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeCategory === cat
                  ? 'bg-emerald-700 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Solutions Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredSolutions.map((sol) => {
            const Icon = iconMap[sol.icon] || Cpu;

            return (
              <div
                key={sol.id}
                className="group relative rounded-3xl p-6 bg-slate-50/70 border border-slate-200 hover:border-emerald-400 hover:bg-white hover:shadow-xl transition-all duration-300 flex flex-col justify-between text-left"
              >
                <div>
                  {/* Top Bar: Icon & Category Tag */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-white shadow-sm border border-slate-100 flex items-center justify-center text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full ${sol.tagColor}`}>
                      {sol.tag}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-slate-900 group-hover:text-emerald-800 transition-colors leading-snug">
                    {sol.title}
                  </h3>

                  <p className="text-xs text-slate-600 mt-2.5 leading-relaxed line-clamp-3">
                    {sol.summary}
                  </p>

                  {/* Highlights Mini Badge */}
                  <div className="mt-4 pt-3 border-t border-slate-200/60 flex items-center justify-between text-[11px] text-slate-500">
                    <span className="font-semibold text-emerald-700">
                      {sol.stats.speed || sol.stats.throughput || sol.stats.returnRates || sol.stats.energySaving}
                    </span>
                    <span className="text-slate-400">
                      {sol.category}
                    </span>
                  </div>
                </div>

                {/* Learn Details CTA Button */}
                <div className="mt-6 pt-2">
                  <button
                    onClick={() => setSelectedSolution(sol)}
                    className="w-full flex items-center justify-between px-4 py-2.5 rounded-xl bg-white group-hover:bg-emerald-50 text-slate-700 group-hover:text-emerald-800 font-semibold text-xs border border-slate-200 group-hover:border-emerald-200 transition-all cursor-pointer shadow-xs"
                  >
                    <span>Inspect Mechanism & Limits</span>
                    <ArrowUpRight className="w-4 h-4 text-emerald-600 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                  </button>
                </div>

              </div>
            );
          })}
        </div>

      </div>

      {/* Modal: Deep Dive into Solution Architecture & Limits */}
      {selectedSolution && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto text-left relative">
            
            {/* Close Button */}
            <button
              onClick={() => setSelectedSolution(null)}
              className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header */}
            <div className="pr-10">
              <span className={`inline-block text-[11px] font-bold px-2.5 py-1 rounded-full mb-2 ${selectedSolution.tagColor}`}>
                {selectedSolution.tag}
              </span>
              <h3 className="text-2xl font-extrabold text-slate-900">
                {selectedSolution.title}
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Domain: {selectedSolution.category}
              </p>
            </div>

            {/* How It Works */}
            <div className="mt-6">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                How It Works:
              </h4>
              <p className="text-sm text-slate-700 leading-relaxed bg-slate-50 p-4 rounded-2xl border border-slate-200/70">
                {selectedSolution.howItWorks}
              </p>
            </div>

            {/* Performance Stats Pill Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 my-5">
              {Object.entries(selectedSolution.stats).map(([k, v]) => (
                <div key={k} className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-100">
                  <div className="text-[10px] uppercase font-bold text-emerald-800 tracking-wider">
                    {k.replace(/([A-Z])/g, ' $1')}
                  </div>
                  <div className="text-xs font-bold text-slate-800 mt-0.5 truncate" title={v}>
                    {v}
                  </div>
                </div>
              ))}
            </div>

            {/* Key Benefits */}
            <div className="my-5">
              <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-700 mb-2.5 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Documented Benefits:</span>
              </h4>
              <ul className="space-y-2">
                {selectedSolution.benefits.map((b, i) => (
                  <li key={i} className="flex items-start gap-2.5 text-xs text-slate-700">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                    <span>{b}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Real-World Limitations & Challenges */}
            <div className="my-5">
              <h4 className="text-xs font-bold uppercase tracking-wider text-rose-700 mb-2.5 flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-rose-600" />
                <span>Critical Limitations & Constraints:</span>
              </h4>
              <ul className="space-y-2 bg-rose-50/50 p-4 rounded-2xl border border-rose-100">
                {selectedSolution.limitations.map((l, i) => (
                  <li key={i} className="flex items-start gap-2.5 text-xs text-rose-950 font-medium">
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mt-1.5 shrink-0" />
                    <span>{l}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Bottom Dismiss */}
            <div className="pt-4 border-t border-slate-100 flex justify-end">
              <button
                onClick={() => setSelectedSolution(null)}
                className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shadow-xs cursor-pointer"
              >
                Close Overview
              </button>
            </div>

          </div>
        </div>
      )}

    </section>
  );
}
