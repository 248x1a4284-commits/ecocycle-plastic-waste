// Data for Plastic Pollution Awareness section
export const pollutionFacts = [
  {
    id: 'land-water',
    title: 'Land & Freshwater Contamination',
    badge: 'Terrestrial Crisis',
    summary: 'Millions of metric tons of plastic waste leak into agricultural soils, rivers, and groundwater each year.',
    description: 'Terrestrial microplastic pollution is estimated to be 4 to 23 times higher than ocean pollution. Plastic film mulches and degraded packaging break into micro- and nanoplastics that alter soil microbiology, reduce crop yields, and clog river systems before reaching estuaries.',
    keyStats: ['79% of plastic waste ever made sits in landfills or open nature', 'Over 1,000 rivers account for 80% of global riverine plastic inputs into the sea'],
    icon: 'Mountain',
    color: 'emerald',
    image: 'https://images.unsplash.com/photo-1618477388954-7852f32655ec?auto=format&fit=crop&w=800&q=80',
    tags: ['Soil Degradation', 'River Systems', 'Agricultural Runoff']
  },
  {
    id: 'marine-life',
    title: 'Marine Wildlife & Ocean Ecosystems',
    badge: 'Ocean Impact',
    summary: 'Over 800 marine species are documented to ingest or become entangled in marine debris, causing fatal injuries.',
    description: 'From deep-sea trenches to Arctic sea ice, floating plastic debris forms gyres like the Great Pacific Garbage Patch. Sea turtles mistake plastic bags for jellyfish, seabirds feed floating plastic bits to their chicks, and ghost fishing nets drift indefinitely, trapping marine mammals, fish, and sharks.',
    keyStats: ['100,000+ marine mammals and over 1 million seabirds killed annually', '14+ million metric tons of plastic enter oceans every single year'],
    icon: 'Waves',
    color: 'sky',
    image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=800&q=80',
    tags: ['Ghost Nets', 'Ingestion & Entanglement', 'Coral Reef Damage']
  },
  {
    id: 'human-health',
    title: 'Human Health & Trophic Bioaccumulation',
    badge: 'Human Risk',
    summary: 'Microplastics have been detected in human blood, lung tissue, placenta, and everyday drinking water and food.',
    description: 'Plastics contain hazardous chemical additives including phthalates, bisphenols (BPA/BPS), PFAS, and heavy metals. When plastics fragment into nanometer particles, they cross biological membranes. Recent studies estimate humans ingest the equivalent of one credit card worth of plastic per week via water, sea salt, shellfish, and airborne dust.',
    keyStats: ['Detected in 93% of bottled water tested across 9 countries', 'Linked to endocrine disruption, systemic inflammation, and cellular stress'],
    icon: 'HeartPulse',
    color: 'amber',
    image: 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?auto=format&fit=crop&w=800&q=80',
    tags: ['Microplastics in Blood', 'Endocrine Disruptors', 'Food Chain Transfer']
  },
  {
    id: 'single-use',
    title: 'The Single-Use Plastic Epidemic',
    badge: 'Systemic Root Cause',
    summary: 'Around 50% of all plastics produced annually are designed to be discarded within minutes of a single use.',
    description: 'Takeaway food packaging, straws, multi-layer snack sachets, disposable cutlery, and checkout bags dominate coastal trash cleanups. These items have negligible scrap value, are rarely captured by municipal curbside recycling, and persist in ecosystems for 400 to 1,000 years.',
    keyStats: ['500 billion plastic bags used worldwide per year (1 million per minute)', 'Single-use packaging makes up ~40% of global virgin plastic demand'],
    icon: 'AlertTriangle',
    color: 'rose',
    image: 'https://images.unsplash.com/photo-1605600659908-0ef719419d41?auto=format&fit=crop&w=800&q=80',
    tags: ['Short Lifespan', 'Non-Recyclable Multilayers', 'Fossil Fuel Dependency']
  }
];

export const plasticComparison = [
  {
    type: 'Biodegradable & Compostable Plastics',
    resinCode: 'Often PLA, PHA, or PBAT (marked #7 Other)',
    badge: 'Bio-Based / Compostable',
    badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    degradation: '60–180 days in Industrial Composting (at 58°C+ with microbes)',
    properties: 'Derived from corn starch, sugarcane, or bacterial synthesis. Requires specific heat, oxygen, and moisture to break down.',
    disposalGuide: 'Must go to commercial industrial organics facility. Will NOT break down quickly in cold ocean water or home compost (unless labeled "Home Compostable"). Do NOT place in curbside plastic recycling—it contaminates PET/HDPE streams.',
    pros: ['Reduces fossil fuel feedstocks', 'Breaks down into water, CO2, and organic biomass in controlled facilities', 'Lower carbon footprint during raw synthesis'],
    cons: ['Cannot be recycled with regular plastics', 'Requires certified industrial composting infrastructure', 'Often litters environments if consumers misunderstand labeling']
  },
  {
    type: 'Mechanically Recyclable Plastics',
    resinCode: 'Primary Codes: #1 PET, #2 HDPE, #5 PP',
    badge: 'Standard Recyclable',
    badgeColor: 'bg-blue-100 text-blue-800 border-blue-300',
    degradation: '200 to 500+ years in nature if discarded',
    properties: 'Thermoplastics that melt under heat and can be reformed into recycled pellets, fiber, or new rigid containers.',
    disposalGuide: 'Empty, rinse, dry, and place into designated recycling bin. Keep caps screwed onto bottles to prevent small parts falling through sorting screens.',
    pros: ['Well-established collection infrastructure in many cities', 'High market scrap value for clean PET and HDPE', 'Saves up to 70% energy compared to producing virgin plastic'],
    cons: ['Polymer chains degrade after 2–3 mechanical cycles (downcycling)', 'Easily contaminated by food residues, labels, and mixed resins', 'Less than 15% globally captured in practice']
  },
  {
    type: 'Non-Recyclable / Difficult Plastics',
    resinCode: 'Codes: #3 PVC, #6 PS / EPS, #7 Mixed Multilayers',
    badge: 'Non-Recyclable / Hard-to-Recycle',
    badgeColor: 'bg-rose-100 text-rose-800 border-rose-300',
    degradation: '500 to 1,000+ years (breaks into microplastics indefinitely)',
    properties: 'Multilayer film sachets (aluminum + plastic), expanded polystyrene (Styrofoam), toxic chlorinated PVC, and composite plastics.',
    disposalGuide: 'Must be placed in non-recyclable landfill or designated waste-to-energy bin. Never mix with curbside recyclables as they jam automated optical sorters.',
    pros: ['Very cheap to manufacture', 'High barrier resistance for extended food shelf-life', 'Lightweight for long-distance transport'],
    cons: ['Economically unviable to separate and mechanically recycle', 'Releases toxic dioxins and hydrochloric acid if incinerated poorly', 'Primary contributor to persistent environmental litter']
  }
];
