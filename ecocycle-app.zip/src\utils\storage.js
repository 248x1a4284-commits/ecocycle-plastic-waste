// LocalStorage management utility for EcoCycle

const STORAGE_KEYS = {
  CHALLENGES: 'ecocycle_challenges_v1',
  FOOTPRINT: 'ecocycle_footprint_v1',
  AVOIDED_ITEMS: 'ecocycle_avoided_items_v1',
  COMMUNITY_CENTERS: 'ecocycle_community_centers_v1',
  REDUCTION_GOAL: 'ecocycle_reduction_goal_v1',
  RECENT_SEARCHES: 'ecocycle_recent_searches_v1'
};

export const getStoredChallenges = () => {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.CHALLENGES);
    return data ? JSON.parse(data) : {};
  } catch (e) {
    console.error('Error reading challenges from storage', e);
    return {};
  }
};

export const saveStoredChallenges = (challenges) => {
  try {
    localStorage.setItem(STORAGE_KEYS.CHALLENGES, JSON.stringify(challenges));
  } catch (e) {
    console.error('Error saving challenges to storage', e);
  }
};

export const getStoredFootprint = () => {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.FOOTPRINT);
    return data ? JSON.parse(data) : null;
  } catch (e) {
    console.error('Error reading footprint from storage', e);
    return null;
  }
};

export const saveStoredFootprint = (footprint) => {
  try {
    localStorage.setItem(STORAGE_KEYS.FOOTPRINT, JSON.stringify(footprint));
  } catch (e) {
    console.error('Error saving footprint to storage', e);
  }
};

export const getStoredAvoidedItems = () => {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.AVOIDED_ITEMS);
    return data ? JSON.parse(data) : { bottles: 6, bags: 12, containers: 4, straws: 15, sortedItems: 28 };
  } catch (e) {
    console.error('Error reading avoided items', e);
    return { bottles: 6, bags: 12, containers: 4, straws: 15, sortedItems: 28 };
  }
};

export const saveStoredAvoidedItems = (items) => {
  try {
    localStorage.setItem(STORAGE_KEYS.AVOIDED_ITEMS, JSON.stringify(items));
  } catch (e) {
    console.error('Error saving avoided items', e);
  }
};

export const getStoredCenters = () => {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.COMMUNITY_CENTERS);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    console.error('Error reading community centers', e);
    return [];
  }
};

export const saveStoredCenters = (centers) => {
  try {
    localStorage.setItem(STORAGE_KEYS.COMMUNITY_CENTERS, JSON.stringify(centers));
  } catch (e) {
    console.error('Error saving community centers', e);
  }
};

export const getStoredReductionGoal = () => {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.REDUCTION_GOAL);
    return data ? JSON.parse(data) : { targetAvoidedPerMonth: 60, currentMonth: 37 };
  } catch (e) {
    return { targetAvoidedPerMonth: 60, currentMonth: 37 };
  }
};

export const saveStoredReductionGoal = (goal) => {
  try {
    localStorage.setItem(STORAGE_KEYS.REDUCTION_GOAL, JSON.stringify(goal));
  } catch (e) {
    console.error('Error saving reduction goal', e);
  }
};
