import React, { useState } from 'react';
import { 
  Recycle, 
  Mail, 
  Send, 
  ExternalLink, 
  Heart, 
  ShieldCheck, 
  Globe2, 
  CheckCircle2, 
  X,
  Phone,
  MessageSquare
} from 'lucide-react';

export default function Footer() {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterSubscribed, setNewsletterSubscribed] = useState(false);
  const [contactModalOpen, setContactModalOpen] = useState(false);
  const [contactForm, setContactForm] = useState({ name: '', email: '', subject: 'General Inquiry', message: '' });
  const [contactSent, setContactSent] = useState(false);

  const handleNewsletterSubmit = (e) => {
    e.preventDefault();
    if (newsletterEmail) {
      setNewsletterSubscribed(true);
      setTimeout(() => {
        setNewsletterEmail('');
      }, 2500);
    }
  };

  const handleContactSubmit = (e) => {
    e.preventDefault();
    if (contactForm.name && contactForm.email && contactForm.message) {
      setContactSent(true);
      setTimeout(() => {
        setContactSent(false);
        setContactModalOpen(false);
        setContactForm({ name: '', email: '', subject: 'General Inquiry', message: '' });
      }, 2000);
    }
  };

  const credibleResources = [
    { name: 'UNEP Beat Plastic Pollution', url: 'https://www.unep.org/interactives/beat-plastic-pollution/', org: 'United Nations Environment Programme' },
    { name: 'The Ocean Cleanup', url: 'https://theoceancleanup.com/', org: 'Ocean & River Extraction Tech' },
    { name: 'Ellen MacArthur Foundation', url: 'https://www.ellenmacarthurfoundation.org/topics/plastics/overview', org: 'New Plastics Economy' },
    { name: 'Plastic Soup Foundation', url: 'https://www.plasticsoupfoundation.org/en/', org: 'Microplastics & Health' },
    { name: 'Break Free From Plastic', url: 'https://www.breakfreefromplastic.org/', org: 'Global Policy & Brand Audits' },
    { name: 'IUCN Marine Plastics Brief', url: 'https://www.iucn.org/resources/issues-brief/marine-plastic-pollution', org: 'Conservation Science' },
  ];

  const quickNav = [
    { label: 'Pollution Crisis', href: '#awareness' },
    { label: 'Smart Tech Solutions', href: '#solutions' },
    { label: 'Plastic Footprint Calculator', href: '#calculator' },
    { label: 'Waste Sorting Guide', href: '#guide' },
    { label: '7-Day Eco Challenge', href: '#challenge' },
    { label: 'Recycling Locator', href: '#locator' },
    { label: 'Impact Dashboard', href: '#dashboard' },
    { label: 'Action Blueprints', href: '#action' },
  ];

  const handleNavClick = (e, href) => {
    e.preventDefault();
    const el = document.querySelector(href);
    if (el) {
      const navOffset = 80;
      const elementPosition = el.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - navOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <footer className="bg-slate-900 text-slate-300 pt-16 pb-12 border-t border-slate-800 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 pb-14 border-b border-slate-800 text-left">
          
          {/* Brand Info & Mission (Col 1-4) */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-sky-400 flex items-center justify-center text-slate-900 shadow-md">
                <Recycle className="w-5 h-5 text-white" />
              </div>
              <div>
                <span className="font-extrabold text-xl text-white tracking-tight">EcoCycle</span>
                <span className="text-[10px] font-semibold uppercase tracking-wider text-emerald-400 block -mt-1">
                  Smart Plastic Waste Management
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Empowering individuals, institutions, and municipalities with smart waste intelligence, 
              AI optical sorting awareness, and verified recovery infrastructure to eliminate single-use plastics.
            </p>

            <div className="pt-2 flex flex-col gap-2 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-emerald-400" />
                <span>contact@ecocycle-initiative.org</span>
              </div>
              <div className="flex items-center gap-2">
                <Globe2 className="w-4 h-4 text-sky-400" />
                <span>Global Open Knowledge & Environmental Action Hub</span>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => setContactModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 text-xs font-semibold border border-slate-700 transition-colors cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Open Contact & Partnerships Desk</span>
              </button>
            </div>
          </div>

          {/* Quick Platform Links (Col 5-7) */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Platform Features
            </h4>
            <ul className="space-y-2 text-xs">
              {quickNav.map((item) => (
                <li key={item.label}>
                  <a
                    href={item.href}
                    onClick={(e) => handleNavClick(e, item.href)}
                    className="hover:text-emerald-400 transition-colors inline-block"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Credible Global Resources (Col 8-10) */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Credible Scientific Resources
            </h4>
            <ul className="space-y-2 text-xs">
              {credibleResources.map((res) => (
                <li key={res.name}>
                  <a
                    href={res.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between text-slate-400 hover:text-emerald-400 transition-colors group"
                  >
                    <span className="truncate pr-2">{res.name}</span>
                    <ExternalLink className="w-3 h-3 text-slate-600 group-hover:text-emerald-400 shrink-0" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter Subscribe (Col 11-12) */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Stay Informed
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Receive monthly briefs on clean tech policies, biopolymer research, and zero-waste campus guides.
            </p>

            <form onSubmit={handleNewsletterSubmit} className="space-y-2">
              <input
                type="email"
                required
                placeholder="Your email address..."
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
              <button
                type="submit"
                className="w-full py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <span>{newsletterSubscribed ? 'Subscribed! ✓' : 'Subscribe'}</span>
                {!newsletterSubscribed && <Send className="w-3 h-3" />}
              </button>
            </form>
          </div>

        </div>

        {/* Bottom Bar: Copyright & Commitment */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 text-center sm:text-left">
          <div>
            © {new Date().getFullYear()} <strong>EcoCycle</strong> – Smart Plastic Waste Management. Built with modern React, Tailwind CSS, & Clean Tech.
          </div>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              Aligned with UN Sustainable Development Goal #12 & #14
            </span>
          </div>
        </div>

      </div>

      {/* Contact Modal */}
      {contactModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-slate-200 text-left text-slate-900 relative">
            
            <button
              onClick={() => setContactModalOpen(false)}
              className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="mb-4">
              <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-2.5 py-1 rounded-md">
                Connect With EcoCycle
              </span>
              <h3 className="text-xl font-bold mt-1 text-slate-900">
                Contact & Environmental Inquiry
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Questions about campus deployment, municipal data integration, or partnerships? Send us a note.
              </p>
            </div>

            {contactSent ? (
              <div className="py-8 text-center bg-emerald-50 rounded-2xl border border-emerald-200 p-4">
                <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto mb-2" />
                <h4 className="text-base font-bold text-emerald-900">Message Delivered!</h4>
                <p className="text-xs text-emerald-700 mt-1">
                  Thank you for reaching out. An EcoCycle team member will review your inquiry shortly.
                </p>
              </div>
            ) : (
              <form onSubmit={handleContactSubmit} className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Your Full Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Alex Rivera"
                    value={contactForm.name}
                    onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    placeholder="alex@domain.edu"
                    value={contactForm.email}
                    onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Inquiry Topic</label>
                  <select
                    value={contactForm.subject}
                    onChange={(e) => setContactForm({ ...contactForm, subject: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
                  >
                    <option>General Inquiry</option>
                    <option>Campus / University Program</option>
                    <option>Municipal Recycling Center Listing</option>
                    <option>Technology & AI Research Collaboration</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Message</label>
                  <textarea
                    rows="3"
                    required
                    placeholder="How can we assist your sustainability initiative?"
                    value={contactForm.message}
                    onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setContactModalOpen(false)}
                    className="px-4 py-2 text-xs font-semibold text-slate-500 hover:text-slate-800"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md transition-colors cursor-pointer"
                  >
                    Send Inquiry
                  </button>
                </div>
              </form>
            )}

          </div>
        </div>
      )}

    </footer>
  );
}
