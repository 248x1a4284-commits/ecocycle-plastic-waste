import React, { useState } from 'react';
import { 
  TrendingUp, 
  AlertCircle, 
  Waves, 
  Clock, 
  ExternalLink, 
  CheckCircle, 
  Info 
} from 'lucide-react';

export default function StatsBanner() {
  const [activeTooltip, setActiveTooltip] = useState(null);

  const stats = [
    {
      id: 'production',
      value: '460M+',
      unit: 'Metric Tons / Year',
      label: 'Global Virgin Plastic Production',
      subtext: 'More than doubled in the last 20 years, with over 60% ending as waste.',
      source: 'OECD Global Plastics Outlook Report (2022/2024)',
      sourceUrl: 'https://www.oecd.org/environment/plastics/',
      icon: TrendingUp,
      color: 'emerald',
      bgGradient: 'from-emerald-500/10 to-teal-500/5',
      borderColor: 'border-emerald-200'
    },
    {
      id: 'recycling-rate',
      value: 'Only ~9%',
      unit: 'Global Recycled Fraction',
      label: 'Plastic Waste Successfully Recycled',
      subtext: '19% is incinerated, 50% ends in landfills, and 22% mismanaged into nature.',
      source: 'UNEP – United Nations Environment Programme',
      sourceUrl: 'https://www.unep.org/interactives/beat-plastic-pollution/',
      icon: AlertCircle,
      color: 'amber',
      bgGradient: 'from-amber-500/10 to-orange-500/5',
      borderColor: 'border-amber-200'
    },
    {
      id: 'ocean-input',
      value: '14M+',
      unit: 'Tons Entering Oceans Yearly',
      label: 'Marine Plastic Leakage',
      subtext: 'Threatens 800+ marine species through choking, toxicity, and ingestion.',
      source: 'IUCN Marine Plastics Brief & Ocean Conservancy',
      sourceUrl: 'https://www.iucn.org/resources/issues-brief/marine-plastic-pollution',
      icon: Waves,
      color: 'sky',
      bgGradient: 'from-sky-500/10 to-blue-500/5',
      borderColor: 'border-sky-200'
    },
    {
      id: 'breakdown-time',
      value: '450+ Yrs',
      unit: 'Estimated Decomposition',
      label: 'Lifespan of a Single Plastic Bottle',
      subtext: 'Does not biodegrade organically—fragments into hazardous micro- and nanoplastics.',
      source: 'NOAA (National Oceanic and Atmospheric Admin)',
      sourceUrl: 'https://marinedebris.noaa.gov/',
      icon: Clock,
      color: 'rose',
      bgGradient: 'from-rose-500/10 to-red-500/5',
      borderColor: 'border-rose-200'
    }
  ];

  return (
    <section className="relative -mt-6 z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
      <div className="bg-white/95 backdrop-blur-xl rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-200/80">
        
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 mb-6 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-emerald-600" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-800">
                Verified Global Environmental Baselines
              </h3>
            </div>
            <p className="text-slate-500 text-xs sm:text-sm mt-0.5">
              Peer-reviewed data on global plastic mass flows and ecological accumulation
            </p>
          </div>
          
          <div className="inline-flex items-center gap-1.5 text-xs text-slate-500 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200/60 self-start sm:self-auto">
            <Info className="w-3.5 h-3.5 text-emerald-600" />
            <span>Click any card to inspect credible scientific sources</span>
          </div>
        </div>

        {/* 4 Animated Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat) => {
            const Icon = stat.icon;
            const isSelected = activeTooltip === stat.id;

            return (
              <div
                key={stat.id}
                onClick={() => setActiveTooltip(isSelected ? null : stat.id)}
                className={`relative rounded-2xl p-5 border transition-all duration-300 cursor-pointer bg-gradient-to-br ${stat.bgGradient} ${
                  isSelected ? `${stat.borderColor} ring-2 ring-emerald-500/30 shadow-md` : 'border-slate-200/70 hover:border-emerald-300 hover:shadow-md'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold uppercase tracking-wide text-slate-500">
                    {stat.unit}
                  </span>
                  <div className={`p-2 rounded-xl bg-white shadow-xs border border-slate-100 ${
                    stat.color === 'emerald' ? 'text-emerald-600' :
                    stat.color === 'amber' ? 'text-amber-600' :
                    stat.color === 'sky' ? 'text-sky-600' : 'text-rose-600'
                  }`}>
                    <Icon className="w-4 h-4" />
                  </div>
                </div>

                <div className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
                  {stat.value}
                </div>

                <h4 className="text-sm font-bold text-slate-800 mt-1 line-clamp-1">
                  {stat.label}
                </h4>

                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  {stat.subtext}
                </p>

                {/* Source Label */}
                <div className="mt-4 pt-3 border-t border-slate-200/50 flex items-center justify-between text-[11px] text-slate-500 font-medium">
                  <span className="truncate max-w-[170px]" title={stat.source}>
                    Source: {stat.source.split('–')[0]}
                  </span>
                  <span className="text-emerald-700 font-semibold flex items-center gap-1 hover:underline">
                    Verify
                    <ExternalLink className="w-3 h-3" />
                  </span>
                </div>

                {/* Expanded Source Details Modal / Tooltip */}
                {isSelected && (
                  <div className="mt-3 p-3 bg-white rounded-xl shadow-lg border border-emerald-200 text-xs text-slate-700 animate-in fade-in duration-200">
                    <div className="flex items-start gap-1.5 font-semibold text-emerald-900 mb-1">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <span>Credible Citation:</span>
                    </div>
                    <p className="text-[11px] text-slate-600 mb-2">{stat.source}</p>
                    <a
                      href={stat.sourceUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => e.stopPropagation()}
                      className="inline-flex items-center gap-1 text-[11px] text-emerald-700 hover:text-emerald-800 font-bold underline"
                    >
                      Visit Official Publication <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
