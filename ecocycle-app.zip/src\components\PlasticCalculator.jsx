import React, { useState, useEffect } from 'react';
import { 
  Calculator, 
  Droplet, 
  ShoppingBag, 
  Utensils, 
  Coffee, 
  Package, 
  Sparkles, 
  CheckCircle, 
  AlertTriangle, 
  RotateCcw, 
  Save, 
  ArrowRight,
  Info
} from 'lucide-react';
import { getStoredFootprint, saveStoredFootprint } from '../utils/storage';

export default function PlasticCalculator({ onFootprintSaved }) {
  // Weekly inputs
  const [bottles, setBottles] = useState(4);
  const [bags, setBags] = useState(5);
  const [containers, setContainers] = useState(3);
  const [cupsStraws, setCupsStraws] = useState(4);
  const [wrappers, setWrappers] = useState(6);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Load stored inputs on mount
  useEffect(() => {
    const saved = getStoredFootprint();
    if (saved && saved.inputs) {
      setBottles(saved.inputs.bottles ?? 4);
      setBags(saved.inputs.bags ?? 5);
      setContainers(saved.inputs.containers ?? 3);
      setCupsStraws(saved.inputs.cupsStraws ?? 4);
      setWrappers(saved.inputs.wrappers ?? 6);
    }
  }, []);

  // Compute metrics
  const weeklyItems = bottles + bags + containers + cupsStraws + wrappers;
  const yearlyItems = weeklyItems * 52;
  
  // Approximate weights (grams): bottle 20g, bag 6g, container 35g, cup/straw 18g, wrapper 4g
  const weeklyGrams = (bottles * 20) + (bags * 6) + (containers * 35) + (cupsStraws * 18) + (wrappers * 4);
  const yearlyKg = ((weeklyGrams * 52) / 1000).toFixed(1);

  // Approximate CO2e factor (kg CO2e per kg plastic produced and discarded ~ 3.5 kg CO2e/kg)
  const yearlyCO2e = (yearlyKg * 3.4).toFixed(1);

  // Determine Footprint Tier
  let tier = {
    label: 'Moderate Footprint',
    color: 'text-amber-700 bg-amber-50 border-amber-200',
    description: 'You are within typical urban usage ranges, but simple reusable swaps can cut your plastic waste by over 60% immediately.'
  };

  if (weeklyItems <= 10) {
    tier = {
      label: 'Eco Champion (Low Footprint)',
      color: 'text-emerald-700 bg-emerald-50 border-emerald-200',
      description: 'Outstanding mindful habits! You are well below national single-use disposal averages.'
    };
  } else if (weeklyItems > 30) {
    tier = {
      label: 'High Plastic Footprint',
      color: 'text-rose-700 bg-rose-50 border-rose-200',
      description: 'Your current consumption leads to significant plastic leakage and fossil fuel demand. Immediate intervention recommended.'
    };
  }

  // Generate tailored recommendations based on highest categories
  const recommendations = [];
  if (bottles > 2) {
    recommendations.push({
      item: 'Plastic Bottles',
      swap: 'Switch to a 1-liter vacuum insulated stainless steel flask',
      impact: `Save ~${bottles * 52} single-use PET bottles and \$${(bottles * 52 * 1.5).toFixed(0)} per year`
    });
  }
  if (bags > 2) {
    recommendations.push({
      item: 'Plastic Shopping Bags',
      swap: 'Carry a washable cotton tote or clip-on nylon pouch in your backpack',
      impact: `Prevent ~${bags * 52} lightweight polyethylene bags from choking storm drains and ocean life`
    });
  }
  if (containers > 1) {
    recommendations.push({
      item: 'Takeaway Food Containers',
      swap: 'Keep a clean stainless steel tiffin or collapsible silicone box for takeout lunches',
      impact: `Avoid ~${containers * 52} heavy PP/polystyrene containers and eliminate microplastic leaching into hot meals`
    });
  }
  if (cupsStraws > 2) {
    recommendations.push({
      item: 'Cups & Straws',
      swap: 'Request drinks with "No straw" and carry a reusable travel tumbler for iced coffee/tea',
      impact: `Keep ~${cupsStraws * 52} plastic straws and non-recyclable lined cups out of landfills`
    });
  }
  if (wrappers > 4) {
    recommendations.push({
      item: 'Single-Serving Snack Wrappers',
      swap: 'Purchase nuts, dried fruits, and snacks in bulk jars or make your own trail mix',
      impact: `Drastically cuts down on non-recyclable multi-layer metalized plastic packaging`
    });
  }

  const handleSaveToDashboard = () => {
    const footprintData = {
      inputs: { bottles, bags, containers, cupsStraws, wrappers },
      weeklyItems,
      yearlyItems,
      yearlyKg,
      yearlyCO2e,
      tier: tier.label,
      updatedAt: new Date().toISOString()
    };
    saveStoredFootprint(footprintData);
    setSavedSuccess(true);
    if (onFootprintSaved) {
      onFootprintSaved(footprintData);
    }
    setTimeout(() => setSavedSuccess(false), 3500);
  };

  const handleReset = () => {
    setBottles(0);
    setBags(0);
    setContainers(0);
    setCupsStraws(0);
    setWrappers(0);
  };

  return (
    <section id="calculator" className="py-20 bg-gradient-to-b from-white via-emerald-50/30 to-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wider mb-3">
            <Calculator className="w-3.5 h-3.5 text-emerald-600" />
            <span>Interactive Assessment</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Calculate Your Plastic Footprint
          </h2>
          <p className="mt-3 text-base text-slate-600">
            Estimate your weekly and yearly single-use plastic consumption, discover personalized eco-swaps, 
            and track your reduction journey directly on your dashboard.
          </p>
        </div>

        {/* Main Grid: Inputs on Left, Results on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Inputs Card */}
          <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-200/80 text-left">
            <div className="flex items-center justify-between pb-4 mb-6 border-b border-slate-100">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Weekly Plastic Usage</h3>
                <p className="text-xs text-slate-500">Adjust the sliders to match your typical weekly consumption</p>
              </div>
              <button
                onClick={handleReset}
                className="flex items-center gap-1 text-xs text-slate-500 hover:text-rose-600 font-medium transition-colors"
                title="Reset values to 0"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
            </div>

            {/* Slider Input 1: Bottles */}
            <div className="space-y-6">
              <div className="p-4 rounded-2xl bg-slate-50/80 border border-slate-200/60">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-xl bg-sky-100 text-sky-700">
                      <Droplet className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-800">Plastic Water & Drink Bottles</span>
                      <p className="text-[11px] text-slate-500">Single-use PET beverage bottles used per week</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xl font-extrabold text-emerald-700">{bottles}</span>
                    <span className="text-xs text-slate-400 ml-1">/ wk</span>
                  </div>
                </div>
                <input
                  type="range"
                  min="0"
                  max="30"
                  value={bottles}
                  onChange={(e) => setBottles(Number(e.target.value))}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>0 bottles</span>
                  <span>15 bottles</span>
                  <span>30+ bottles</span>
                </div>
              </div>

              {/* Slider Input 2: Bags */}
              <div className="p-4 rounded-2xl bg-slate-50/80 border border-slate-200/60">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-xl bg-amber-100 text-amber-700">
                      <ShoppingBag className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-800">Plastic Grocery & Carry Bags</span>
                      <p className="text-[11px] text-slate-500">Thin supermarket or retail shopping bags per week</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xl font-extrabold text-emerald-700">{bags}</span>
                    <span className="text-xs text-slate-400 ml-1">/ wk</span>
                  </div>
                </div>
                <input
                  type="range"
                  min="0"
                  max="30"
                  value={bags}
                  onChange={(e) => setBags(Number(e.target.value))}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>0 bags</span>
                  <span>15 bags</span>
                  <span>30+ bags</span>
                </div>
              </div>

              {/* Slider Input 3: Containers */}
              <div className="p-4 rounded-2xl bg-slate-50/80 border border-slate-200/60">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-xl bg-rose-100 text-rose-700">
                      <Utensils className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-800">Takeout Food Containers & Cutlery</span>
                      <p className="text-[11px] text-slate-500">Plastic meal boxes, sauce tubs & plastic utensils per week</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xl font-extrabold text-emerald-700">{containers}</span>
                    <span className="text-xs text-slate-400 ml-1">/ wk</span>
                  </div>
                </div>
                <input
                  type="range"
                  min="0"
                  max="25"
                  value={containers}
                  onChange={(e) => setContainers(Number(e.target.value))}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>0 containers</span>
                  <span>12 containers</span>
                  <span>25+ containers</span>
                </div>
              </div>

              {/* Slider Input 4: Cups & Straws */}
              <div className="p-4 rounded-2xl bg-slate-50/80 border border-slate-200/60">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-xl bg-purple-100 text-purple-700">
                      <Coffee className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-800">Disposable Cups, Lids & Straws</span>
                      <p className="text-[11px] text-slate-500">Plastic smoothie cups, iced tea straws & lids per week</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xl font-extrabold text-emerald-700">{cupsStraws}</span>
                    <span className="text-xs text-slate-400 ml-1">/ wk</span>
                  </div>
                </div>
                <input
                  type="range"
                  min="0"
                  max="25"
                  value={cupsStraws}
                  onChange={(e) => setCupsStraws(Number(e.target.value))}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>0 cups</span>
                  <span>12 cups</span>
                  <span>25+ cups</span>
                </div>
              </div>

              {/* Slider Input 5: Wrappers */}
              <div className="p-4 rounded-2xl bg-slate-50/80 border border-slate-200/60">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-xl bg-teal-100 text-teal-700">
                      <Package className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-800">Snack Wrappers & Shipping Mailers</span>
                      <p className="text-[11px] text-slate-500">Chip packets, candy wrappers, bubble wrap per week</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xl font-extrabold text-emerald-700">{wrappers}</span>
                    <span className="text-xs text-slate-400 ml-1">/ wk</span>
                  </div>
                </div>
                <input
                  type="range"
                  min="0"
                  max="30"
                  value={wrappers}
                  onChange={(e) => setWrappers(Number(e.target.value))}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>0 packets</span>
                  <span>15 packets</span>
                  <span>30+ packets</span>
                </div>
              </div>
            </div>

            {/* Scientific Estimation Disclaimer */}
            <div className="mt-6 p-3.5 bg-slate-50 rounded-2xl border border-slate-200 text-xs text-slate-500 flex items-start gap-2.5">
              <Info className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <p>
                <strong>Scientific Disclaimer:</strong> This calculation is an educational estimate 
                based on your self-reported inputs and average polymer weights, not an exact laboratory or municipal waste measurement.
              </p>
            </div>
          </div>

          {/* Results & Actions Card */}
          <div className="lg:col-span-5 space-y-6 text-left">
            <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-200/80">
              
              {/* Tier Badge */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Calculated Status
                </span>
                <span className={`text-xs font-extrabold px-3 py-1 rounded-full border ${tier.color}`}>
                  {tier.label}
                </span>
              </div>

              {/* Main Metric Numbers */}
              <div className="grid grid-cols-2 gap-4 my-6">
                <div className="p-4 rounded-2xl bg-emerald-50/80 border border-emerald-100">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-emerald-800">
                    Weekly Items
                  </div>
                  <div className="text-3xl font-extrabold text-emerald-950 mt-1">
                    {weeklyItems}
                  </div>
                  <div className="text-[11px] text-emerald-700">disposable items / week</div>
                </div>

                <div className="p-4 rounded-2xl bg-teal-50/80 border border-teal-100">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-teal-800">
                    Yearly Projection
                  </div>
                  <div className="text-3xl font-extrabold text-teal-950 mt-1">
                    {yearlyItems.toLocaleString()}
                  </div>
                  <div className="text-[11px] text-teal-700">disposable items / year</div>
                </div>
              </div>

              {/* Mass and Carbon equivalents */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/70 space-y-2 mb-6">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-600">Est. Plastic Mass Waste:</span>
                  <span className="font-bold text-slate-900">{yearlyKg} kg / year</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-600">Est. Lifecycle Greenhouse Gas:</span>
                  <span className="font-bold text-slate-900">{yearlyCO2e} kg CO₂e</span>
                </div>
                <div className="text-[11px] text-slate-400 pt-1 border-t border-slate-200/50">
                  Equivalent to driving ~{(yearlyCO2e * 4.2).toFixed(0)} kilometers in an average petrol car.
                </div>
              </div>

              <p className="text-xs text-slate-600 mb-6 leading-relaxed">
                {tier.description}
              </p>

              {/* Save / Sync Button */}
              <button
                onClick={handleSaveToDashboard}
                className="w-full flex items-center justify-center gap-2 py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-sm shadow-md shadow-emerald-700/20 hover:shadow-lg transition-all cursor-pointer"
              >
                {savedSuccess ? (
                  <>
                    <CheckCircle className="w-4 h-4 text-emerald-200" />
                    <span>Saved & Synced to Dashboard!</span>
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    <span>Save to My Impact Dashboard</span>
                  </>
                )}
              </button>

            </div>

            {/* Practical Swaps Recommendation Box */}
            <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-200/80">
              <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
                <Sparkles className="w-4 h-4 text-emerald-600" />
                <h4 className="text-sm font-bold text-slate-900">
                  High-Impact Practical Swaps for You
                </h4>
              </div>

              {recommendations.length === 0 ? (
                <p className="text-xs text-emerald-700 font-medium bg-emerald-50 p-4 rounded-2xl border border-emerald-100">
                  🎉 Fantastic work! Your plastic consumption is near zero. Maintain your mindful habits and inspire friends!
                </p>
              ) : (
                <div className="space-y-3">
                  {recommendations.slice(0, 3).map((rec, i) => (
                    <div key={i} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/60">
                      <div className="flex items-center justify-between text-xs font-bold text-slate-800">
                        <span>Target: {rec.item}</span>
                        <span className="text-[10px] text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md font-semibold">
                          Recommended
                        </span>
                      </div>
                      <p className="text-xs font-semibold text-emerald-900 mt-1">
                        👉 {rec.swap}
                      </p>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        {rec.impact}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
