import React from 'react';
import { 
  ArrowRight, 
  Calculator, 
  Leaf, 
  Sparkles, 
  Recycle, 
  Cpu, 
  ShieldCheck, 
  Globe2 
} from 'lucide-react';

export default function Hero({ onOpenCalculator, onExploreSolutions }) {
  const scrollTo = (id) => {
    const el = document.getElementById(id);
    if (el) {
      const navOffset = 80;
      const elementPosition = el.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - navOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="hero" className="relative pt-28 pb-16 md:pt-36 md:pb-24 overflow-hidden bg-gradient-to-b from-emerald-50/70 via-teal-50/30 to-white">
      {/* Background Decorative Blobs */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-full overflow-hidden pointer-events-none -z-10">
        <div className="absolute -top-32 -left-20 w-96 h-96 bg-emerald-200/40 rounded-full blur-3xl" />
        <div className="absolute top-48 -right-20 w-96 h-96 bg-sky-200/40 rounded-full blur-3xl" />
        <div className="absolute bottom-10 left-1/3 w-80 h-80 bg-teal-100/50 rounded-full blur-2xl" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Heading, Pitch & CTAs */}
          <div className="lg:col-span-7 text-left space-y-6">
            
            {/* Pill Tag */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-100/80 border border-emerald-200 text-emerald-800 text-xs sm:text-sm font-semibold shadow-xs">
              <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
              <Leaf className="w-4 h-4 text-emerald-600" />
              <span>Next-Gen Environmental Action & Clean Tech</span>
            </div>

            {/* Main Heading */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.12]">
              Turn Plastic Waste into a{' '}
              <span className="bg-gradient-to-r from-emerald-700 via-teal-600 to-sky-600 bg-clip-text text-transparent">
                Sustainable Future
              </span>
            </h1>

            {/* Short Description */}
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl font-normal">
              Plastic pollution is choking our oceans, poisoning river corridors, and invading global food chains. 
              <strong> EcoCycle</strong> unites cutting-edge AI sorting, real-time waste intelligence, and community 
              circular habits to eliminate single-use plastics and accelerate a zero-waste planet.
            </p>

            {/* Dual Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
              <button
                onClick={() => scrollTo('solutions')}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 hover:from-emerald-700 hover:to-teal-800 text-white font-semibold text-sm sm:text-base shadow-lg shadow-emerald-700/25 hover:shadow-xl hover:shadow-emerald-700/35 transition-all transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer"
              >
                <span>Explore Solutions</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => scrollTo('calculator')}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-white hover:bg-slate-50 text-slate-800 font-semibold text-sm sm:text-base border border-slate-200 hover:border-emerald-300 shadow-sm hover:shadow-md transition-all cursor-pointer"
              >
                <Calculator className="w-4 h-4 text-emerald-600" />
                <span>Calculate My Plastic Footprint</span>
              </button>
            </div>

            {/* Mini Trust Badges */}
            <div className="pt-4 flex flex-wrap items-center gap-6 text-xs text-slate-500 border-t border-slate-200/60">
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-emerald-600" />
                <span>AI Optical Sorter Models</span>
              </div>
              <div className="flex items-center gap-2">
                <Globe2 className="w-4 h-4 text-sky-600" />
                <span>UNEP & OECD Aligned Metrics</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-teal-600" />
                <span>Verified Circular Facilities</span>
              </div>
            </div>

          </div>

          {/* Right Column: Interactive Visual Showcase */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              
              {/* Main Card with Real Environmental Imagery */}
              <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-white/80 bg-white group">
                <img
                  src="https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?auto=format&fit=crop&w=1000&q=80"
                  alt="Plastic recycling facility with segregated plastics and clean technology"
                  className="w-full h-80 sm:h-96 object-cover transform group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent" />
                
                {/* Floating Overlay Badge on Image */}
                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-full text-xs font-semibold text-emerald-800 shadow-md flex items-center gap-1.5 border border-emerald-100">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Circular AI Hub</span>
                </div>

                {/* Bottom Card Legend */}
                <div className="absolute bottom-4 left-4 right-4 p-4 rounded-2xl bg-white/95 backdrop-blur-md border border-slate-100 shadow-lg text-left">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                        Systemic Mission
                      </span>
                      <h4 className="text-sm font-bold text-slate-900 mt-1">
                        From Linear Waste to Regenerative Cycles
                      </h4>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Closing the loop on polymer resins through optical sorting, reduction habits, and municipal recovery.
                      </p>
                    </div>
                    <div className="p-2 rounded-xl bg-emerald-600 text-white shrink-0">
                      <Recycle className="w-5 h-5 animate-spin-slow" />
                    </div>
                  </div>
                </div>
              </div>

              {/* Floating Stat Widget 1: Microplastics Avoided */}
              <div className="absolute -bottom-6 -left-6 sm:-left-8 bg-white/95 backdrop-blur-md rounded-2xl p-4 shadow-xl border border-emerald-100 text-left max-w-[210px] hidden sm:block animate-bounce-gentle">
                <div className="flex items-center gap-2 mb-1">
                  <div className="w-3 h-3 rounded-full bg-emerald-500 animate-ping" />
                  <span className="text-[11px] font-bold text-slate-700 uppercase">Live Community</span>
                </div>
                <div className="text-xl font-extrabold text-emerald-700">84,200+</div>
                <div className="text-[11px] text-slate-500 leading-tight">
                  Single-use plastic items diverted through smart segregation
                </div>
              </div>

              {/* Floating Stat Widget 2: Recovery Rate */}
              <div className="absolute -top-6 -right-4 sm:-right-6 bg-white/95 backdrop-blur-md rounded-2xl p-3.5 shadow-xl border border-sky-100 text-left hidden sm:block">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-sky-500" />
                  <span className="text-xs font-semibold text-slate-600">Pure rPET Feedstock</span>
                </div>
                <div className="text-lg font-bold text-slate-900 mt-0.5">98.4% Pure</div>
                <div className="text-[10px] text-sky-700 font-medium">via AI-assisted optical sorters</div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
