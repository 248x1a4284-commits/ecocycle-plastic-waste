import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  ShieldCheck, 
  CheckCircle2, 
  Trash2, 
  Plus, 
  Target, 
  TrendingDown, 
  BarChart3, 
  Info, 
  Sparkles, 
  Award,
  RefreshCw
} from 'lucide-react';
import { 
  getStoredAvoidedItems, 
  saveStoredAvoidedItems, 
  getStoredChallenges, 
  getStoredFootprint,
  getStoredReductionGoal,
  saveStoredReductionGoal 
} from '../utils/storage';

export default function ImpactDashboard({ footprintData, challengesData }) {
  const [avoidedItems, setAvoidedItems] = useState({
    bottles: 8,
    bags: 14,
    containers: 6,
    straws: 20,
    sortedItems: 32
  });

  const [reductionGoal, setReductionGoal] = useState({
    targetAvoidedPerMonth: 60,
    currentMonth: 48
  });

  const [activeTab, setActiveTab] = useState('overview');
  const [toastMessage, setToastMessage] = useState('');

  // Load from storage
  useEffect(() => {
    const stored = getStoredAvoidedItems();
    if (stored) setAvoidedItems(stored);

    const goal = getStoredReductionGoal();
    if (goal) setReductionGoal(goal);
  }, []);

  const totalAvoidedCount = 
    avoidedItems.bottles + 
    avoidedItems.bags + 
    avoidedItems.containers + 
    avoidedItems.straws;

  const totalChallengesCompleted = Object.values(challengesData || getStoredChallenges()).filter(Boolean).length;
  const currentFootprint = footprintData || getStoredFootprint();

  // Estimated kg diverted = (bottles*20g + bags*6g + containers*35g + straws*2g + sortedItems*25g) / 1000
  const estimatedKgDiverted = (
    (avoidedItems.bottles * 20 + 
     avoidedItems.bags * 6 + 
     avoidedItems.containers * 35 + 
     avoidedItems.straws * 2 + 
     avoidedItems.sortedItems * 25) / 1000
  ).toFixed(2);

  const estimatedCO2Saved = (estimatedKgDiverted * 3.4).toFixed(2);

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 2500);
  };

  const handleLogAvoided = (category, amount = 1) => {
    const updated = {
      ...avoidedItems,
      [category]: (avoidedItems[category] || 0) + amount
    };
    setAvoidedItems(updated);
    saveStoredAvoidedItems(updated);

    // Also bump currentMonth progress in goal
    if (category !== 'sortedItems') {
      const updatedGoal = {
        ...reductionGoal,
        currentMonth: reductionGoal.currentMonth + amount
      };
      setReductionGoal(updatedGoal);
      saveStoredReductionGoal(updatedGoal);
    }

    const labels = {
      bottles: 'Water Bottle Refused',
      bags: 'Plastic Bag Avoided',
      containers: 'Takeaway Box Replaced',
      straws: 'Single-Use Straw Refused',
      sortedItems: 'Item Cleaned & Sorted for Recycling'
    };
    showToast(`+${amount} ${labels[category] || 'Item'} logged!`);
  };

  const goalPercent = Math.min(100, Math.round((reductionGoal.currentMonth / reductionGoal.targetAvoidedPerMonth) * 100));

  // Visual breakdown data
  const breakdownCategories = [
    { label: 'Refused Bottles', count: avoidedItems.bottles, color: 'bg-emerald-500', percent: Math.round((avoidedItems.bottles / Math.max(1, totalAvoidedCount)) * 100) },
    { label: 'Avoided Bags', count: avoidedItems.bags, color: 'bg-teal-500', percent: Math.round((avoidedItems.bags / Math.max(1, totalAvoidedCount)) * 100) },
    { label: 'Substituted Containers', count: avoidedItems.containers, color: 'bg-sky-500', percent: Math.round((avoidedItems.containers / Math.max(1, totalAvoidedCount)) * 100) },
    { label: 'Declined Straws/Lids', count: avoidedItems.straws, color: 'bg-amber-500', percent: Math.round((avoidedItems.straws / Math.max(1, totalAvoidedCount)) * 100) },
  ];

  return (
    <section id="dashboard" className="py-20 bg-slate-50 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wider mb-3">
            <Activity className="w-3.5 h-3.5 text-emerald-600" />
            <span>Personal Environmental Ledger</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            My EcoCycle Impact Dashboard
          </h2>
          <p className="mt-3 text-base text-slate-600">
            Real-time tracking of avoided single-use plastics, verified challenge completions, 
            and items diverted toward recycling facilities.
          </p>

          {/* Toast Notification */}
          {toastMessage && (
            <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white text-xs font-bold rounded-full shadow-lg animate-in fade-in slide-in-from-top-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-200" />
              <span>{toastMessage}</span>
            </div>
          )}
        </div>

        {/* Top 4 Key Indicator Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
          
          {/* Card 1: Items Avoided */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-md text-left">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Single-Use Avoided
              </span>
              <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
                <TrendingDown className="w-4 h-4" />
              </div>
            </div>
            <div className="text-3xl font-extrabold text-slate-900">
              {totalAvoidedCount}
            </div>
            <p className="text-xs text-emerald-700 font-semibold mt-1">
              Estimated items prevented from entering landfills
            </p>
          </div>

          {/* Card 2: 7-Day Challenges Completed */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-md text-left">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                7-Day Challenge Streak
              </span>
              <div className="p-2 rounded-xl bg-teal-50 text-teal-600">
                <Award className="w-4 h-4" />
              </div>
            </div>
            <div className="text-3xl font-extrabold text-slate-900">
              {totalChallengesCompleted} / 7
            </div>
            <p className="text-xs text-teal-700 font-semibold mt-1">
              {totalChallengesCompleted === 7 ? 'Full week mastered!' : 'Daily eco-habits unlocked'}
            </p>
          </div>

          {/* Card 3: Items Sorted & Segregated */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-md text-left">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Sorted for Recovery
              </span>
              <div className="p-2 rounded-xl bg-sky-50 text-sky-600">
                <CheckCircle2 className="w-4 h-4" />
              </div>
            </div>
            <div className="text-3xl font-extrabold text-slate-900">
              {avoidedItems.sortedItems}
            </div>
            <p className="text-xs text-sky-700 font-semibold mt-1">
              Cleaned, capped, & segregated items
            </p>
          </div>

          {/* Card 4: Estimated Plastic Weight & Carbon Saved */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-md text-left">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Est. Diverted Mass
              </span>
              <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
                <Sparkles className="w-4 h-4" />
              </div>
            </div>
            <div className="text-3xl font-extrabold text-slate-900">
              {estimatedKgDiverted} kg
            </div>
            <p className="text-xs text-amber-700 font-semibold mt-1">
              ≈ {estimatedCO2Saved} kg CO₂e emissions averted
            </p>
          </div>

        </div>

        {/* Quick Log Action Bar */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xl mb-10 text-left">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 mb-6 border-b border-slate-100">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Quick Action Logger: Record Today's Eco-Decisions
              </h3>
              <p className="text-xs text-slate-500">
                Tap to record single-use items you actively refused or segregated today.
              </p>
            </div>
            <span className="text-xs font-mono text-emerald-800 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100 self-start sm:self-auto font-semibold">
              Live Auto-Save
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            <button
              onClick={() => handleLogAvoided('bottles')}
              className="p-3.5 rounded-2xl bg-emerald-50/70 hover:bg-emerald-100/80 border border-emerald-200 text-emerald-950 font-semibold text-xs flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
            >
              <Plus className="w-4 h-4 text-emerald-600" />
              <span>+1 Refused Bottle</span>
              <span className="text-[10px] text-emerald-700 font-normal">({avoidedItems.bottles} logged)</span>
            </button>

            <button
              onClick={() => handleLogAvoided('bags')}
              className="p-3.5 rounded-2xl bg-teal-50/70 hover:bg-teal-100/80 border border-teal-200 text-teal-950 font-semibold text-xs flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
            >
              <Plus className="w-4 h-4 text-teal-600" />
              <span>+1 Avoided Bag</span>
              <span className="text-[10px] text-teal-700 font-normal">({avoidedItems.bags} logged)</span>
            </button>

            <button
              onClick={() => handleLogAvoided('containers')}
              className="p-3.5 rounded-2xl bg-sky-50/70 hover:bg-sky-100/80 border border-sky-200 text-sky-950 font-semibold text-xs flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
            >
              <Plus className="w-4 h-4 text-sky-600" />
              <span>+1 Reusable Box</span>
              <span className="text-[10px] text-sky-700 font-normal">({avoidedItems.containers} logged)</span>
            </button>

            <button
              onClick={() => handleLogAvoided('straws')}
              className="p-3.5 rounded-2xl bg-amber-50/70 hover:bg-amber-100/80 border border-amber-200 text-amber-950 font-semibold text-xs flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
            >
              <Plus className="w-4 h-4 text-amber-600" />
              <span>+1 Declined Straw</span>
              <span className="text-[10px] text-amber-700 font-normal">({avoidedItems.straws} logged)</span>
            </button>

            <button
              onClick={() => handleLogAvoided('sortedItems')}
              className="p-3.5 rounded-2xl bg-purple-50/70 hover:bg-purple-100/80 border border-purple-200 text-purple-950 font-semibold text-xs flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95 col-span-2 sm:col-span-1"
            >
              <Plus className="w-4 h-4 text-purple-600" />
              <span>+1 Clean Sorted</span>
              <span className="text-[10px] text-purple-700 font-normal">({avoidedItems.sortedItems} logged)</span>
            </button>
          </div>
        </div>

        {/* Visual Charts & Monthly Goal Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 text-left">
          
          {/* Monthly Reduction Goal Widget */}
          <div className="lg:col-span-6 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xl">
            <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Target className="w-5 h-5 text-emerald-600" />
                <h3 className="text-base font-bold text-slate-900">
                  Monthly Reduction Target
                </h3>
              </div>
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full">
                {goalPercent}% Reached
              </span>
            </div>

            <div className="flex items-baseline justify-between mb-2">
              <span className="text-2xl font-extrabold text-slate-900">
                {reductionGoal.currentMonth} <span className="text-sm font-normal text-slate-500">of {reductionGoal.targetAvoidedPerMonth} items avoided</span>
              </span>
              <span className="text-xs font-semibold text-slate-500">
                Goal: {reductionGoal.targetAvoidedPerMonth} / month
              </span>
            </div>

            {/* Target Progress Bar */}
            <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden p-0.5 border border-slate-200 mb-6">
              <div 
                className="bg-gradient-to-r from-emerald-500 to-teal-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${goalPercent}%` }}
              />
            </div>

            {/* Benchmark vs Verified Data Note */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/70 text-xs text-slate-600 space-y-2">
              <div className="flex items-center gap-1.5 font-bold text-slate-800">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Verification & Scientific Transparency</span>
              </div>
              <p className="text-[11px] leading-relaxed">
                Items logged here are self-reported personal actions. They are calculated using standard 
                polymer lifecycle conversion factors (e.g., 20g/bottle, 3.4kg CO₂e/kg virgin plastic) 
                to provide tangible feedback while strictly distinguishing user estimates from certified municipal scale weights.
              </p>
            </div>
          </div>

          {/* Avoided Plastics Distribution Chart */}
          <div className="lg:col-span-6 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xl">
            <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-emerald-600" />
                <h3 className="text-base font-bold text-slate-900">
                  Avoided Plastic Item Breakdown
                </h3>
              </div>
              <span className="text-xs text-slate-400 font-mono">
                {totalAvoidedCount} Total Logged
              </span>
            </div>

            {/* Interactive Distribution Bars */}
            <div className="space-y-4 pt-2">
              {breakdownCategories.map((item) => (
                <div key={item.label}>
                  <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                    <span>{item.label}</span>
                    <span className="text-slate-500">{item.count} items ({item.percent || 0}%)</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                    <div 
                      className={`${item.color} h-full rounded-full transition-all duration-500`}
                      style={{ width: `${item.percent || 0}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* Sync Footprint Callout */}
            {currentFootprint && (
              <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-500">Calculator Sync:</span>
                <span className="font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-md">
                  Est. Base Weekly Usage: {currentFootprint.weeklyItems} items
                </span>
              </div>
            )}
          </div>

        </div>

      </div>
    </section>
  );
}
