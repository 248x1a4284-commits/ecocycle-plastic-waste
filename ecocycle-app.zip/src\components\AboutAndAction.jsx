import React, { useState } from 'react';
import { 
  GraduationCap, 
  Home, 
  School, 
  Users, 
  CheckCircle2, 
  ArrowRight, 
  Leaf, 
  Target, 
  HeartHandshake, 
  Sparkles,
  Download,
  X
} from 'lucide-react';

export default function AboutAndAction() {
  const [selectedAudience, setSelectedAudience] = useState(null);

  const actionAudiences = [
    {
      id: 'students',
      title: 'Students & Youth',
      icon: GraduationCap,
      badge: 'Campus Advocates',
      color: 'emerald',
      summary: 'Lead peer-to-peer behavioral shifts and audit campus plastic flows.',
      checklist: [
        'Conduct a 3-day personal single-use waste audit to identify unnecessary purchases',
        'Carry a portable zero-waste kit: stainless steel bottle, reusable spork, and cloth napkin',
        'Petition campus dining services to eliminate single-use styrofoam and plastic cutlery',
        'Organize student club "plogging" sessions (jogging while picking up litter)'
      ],
      quickWin: 'Replace disposable plastic ballpoint pens with refillable metal cartridge pens or pencils.'
    },
    {
      id: 'households',
      title: 'Households & Families',
      icon: Home,
      badge: 'Domestic Source Control',
      color: 'teal',
      summary: 'Establish systematic source-segregation and eliminate high-volume single-use packaging.',
      checklist: [
        'Implement strict twin-bin segregation: Wet Organic Waste vs Clean Dry Recyclable Plastics',
        'Buy grains, pulses, and dry foods in bulk using your own cotton drawstring bags or glass jars',
        'Switch bathroom care items to solid shampoo bars, bamboo toothbrushes, and tablet toothpastes',
        'Never microwave food in plastic containers or cover hot food with PVC cling film'
      ],
      quickWin: 'Rinse milk jugs and food tubs immediately with leftover dishwater before residue hardens.'
    },
    {
      id: 'colleges',
      title: 'Colleges & Universities',
      icon: School,
      badge: 'Institutional Leadership',
      color: 'sky',
      summary: 'Institute institutional procurement bans and deploy smart reverse vending kiosks.',
      checklist: [
        'Install chilled contact-free water refilling stations in all academic buildings and dorms',
        'Install automated Reverse Vending Machines (RVMs) linked with student ID reward credits',
        'Mandate reusable dishware and dish-washing stations in all university dining halls and cafeterias',
        'Host student hackathons focused on AI plastic classification and local circular economy models'
      ],
      quickWin: 'Ban single-use plastic water bottles at all university-hosted conferences and sports events.'
    },
    {
      id: 'communities',
      title: 'Communities & Cities',
      icon: Users,
      badge: 'Civic Mobilization',
      color: 'purple',
      summary: 'Advocate for municipal Extended Producer Responsibility (EPR) and neighborhood cleanups.',
      checklist: [
        'Coordinate neighborhood cleanups targeting storm drains and riverbanks before monsoons/rain',
        'Set up a neighborhood "Library of Things" to share party supplies and garden tools without plastic buying',
        'Advocate for city-level ordinances restricting single-use checkout bags and polystyrene foam',
        'Support local informal waste pickers by providing clean, segregated dry recyclables directly'
      ],
      quickWin: 'Partner with local supermarkets to create dedicated polyethylene film return receptacles.'
    }
  ];

  return (
    <section id="action" className="py-20 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Part 1: About EcoCycle Mission & Vision */}
        <div className="mb-20">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            <div className="lg:col-span-6 text-left space-y-5">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wider">
                <Leaf className="w-3.5 h-3.5 text-emerald-600" />
                <span>Our Core Purpose</span>
              </div>

              <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight leading-tight">
                Architecting an End to the Global Plastic Crisis
              </h2>

              <p className="text-base text-slate-600 leading-relaxed">
                <strong>EcoCycle</strong> was founded on the fundamental principle that plastic is not simply a trash problem—it is a design, chemical, and behavioral failure. Every year, over 400 million tons of virgin fossil polymers are manufactured, only to persist for centuries in natural ecosystems.
              </p>

              <p className="text-sm text-slate-600 leading-relaxed">
                By bridging <strong>advanced computer vision</strong>, <strong>transparent material recovery data</strong>, and <strong>grassroots habit transformation</strong>, EcoCycle empowers individuals, campuses, and municipalities to transition from a wasteful linear consumption model to a true regenerative circular economy.
              </p>

              {/* 3 Core Pillars */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-100 text-left">
                  <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-xs mb-2">
                    01
                  </div>
                  <h4 className="text-xs font-bold text-slate-900">Education & Transparency</h4>
                  <p className="text-[11px] text-slate-500 mt-1">Busting recycling myths and debunking greenwashing claims.</p>
                </div>

                <div className="p-4 rounded-2xl bg-teal-50/70 border border-teal-100 text-left">
                  <div className="w-8 h-8 rounded-xl bg-teal-600 text-white flex items-center justify-center font-bold text-xs mb-2">
                    02
                  </div>
                  <h4 className="text-xs font-bold text-slate-900">Smart Technology</h4>
                  <p className="text-[11px] text-slate-500 mt-1">Promoting AI sorting, optical detection, and digital tracking.</p>
                </div>

                <div className="p-4 rounded-2xl bg-sky-50/70 border border-sky-100 text-left">
                  <div className="w-8 h-8 rounded-xl bg-sky-600 text-white flex items-center justify-center font-bold text-xs mb-2">
                    03
                  </div>
                  <h4 className="text-xs font-bold text-slate-900">Grassroots Action</h4>
                  <p className="text-[11px] text-slate-500 mt-1">Equipping households and campuses with actionable tools.</p>
                </div>
              </div>

            </div>

            {/* Visual Column */}
            <div className="lg:col-span-6 relative">
              <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-slate-200 group">
                <img
                  src="https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=1000&q=80"
                  alt="Sustainable community working together on clean green earth"
                  className="w-full h-80 sm:h-96 object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent" />
                
                <div className="absolute bottom-6 left-6 right-6 text-white text-left">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-600/90 text-white text-xs font-semibold mb-2">
                    <HeartHandshake className="w-3.5 h-3.5" />
                    <span>Global Impact Coalition</span>
                  </div>
                  <h3 className="text-xl font-bold">
                    Clean Oceans, Clean Soils, Regenerative Communities
                  </h3>
                  <p className="text-xs text-slate-200 mt-1">
                    Join thousands of daily changemakers recording avoided plastics, auditing packaging, and redirecting resources toward certified recovery centers.
                  </p>
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* Part 2: Take Action Today Section */}
        <div className="pt-8 border-t border-slate-200">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wider mb-3">
              <Target className="w-3.5 h-3.5 text-emerald-600" />
              <span>Tailored Blueprints</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              Take Action Today: Your Practical Blueprint
            </h2>
            <p className="mt-3 text-base text-slate-600">
              Meaningful environmental change happens when solutions match context. 
              Select your role to view concrete steps for high-impact plastic elimination.
            </p>
          </div>

          {/* 4 Sector Action Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 text-left">
            {actionAudiences.map((aud) => {
              const Icon = aud.icon;

              return (
                <div
                  key={aud.id}
                  className="bg-slate-50 rounded-3xl p-6 border border-slate-200/80 hover:border-emerald-400 hover:bg-white hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
                >
                  <div>
                    {/* Header: Icon & Badge */}
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center shadow-xs">
                        <Icon className="w-6 h-6" />
                      </div>
                      <span className="text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-100">
                        {aud.badge}
                      </span>
                    </div>

                    <h3 className="text-lg font-bold text-slate-900">
                      {aud.title}
                    </h3>

                    <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                      {aud.summary}
                    </p>

                    {/* Checklist preview */}
                    <div className="mt-4 pt-3 border-t border-slate-200/60 space-y-2">
                      {aud.checklist.slice(0, 2).map((item, idx) => (
                        <div key={idx} className="flex items-start gap-2 text-xs text-slate-700">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span className="line-clamp-2">{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Button to view complete plan */}
                  <div className="mt-6 pt-3">
                    <button
                      onClick={() => setSelectedAudience(aud)}
                      className="w-full flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-white hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 text-xs font-semibold text-slate-800 hover:text-emerald-800 transition-colors cursor-pointer"
                    >
                      <span>View Full 4-Step Plan</span>
                      <ArrowRight className="w-3.5 h-3.5 text-emerald-600" />
                    </button>
                  </div>

                </div>
              );
            })}
          </div>

        </div>

      </div>

      {/* Modal: Complete Action Plan & Checklist */}
      {selectedAudience && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto text-left relative">
            
            <button
              onClick={() => setSelectedAudience(null)}
              className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="pr-8 mb-5">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md">
                {selectedAudience.badge}
              </span>
              <h3 className="text-2xl font-extrabold text-slate-900 mt-1">
                Action Plan for {selectedAudience.title}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                {selectedAudience.summary}
              </p>
            </div>

            {/* Quick Win Box */}
            <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 mb-5">
              <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900 mb-1">
                <Sparkles className="w-4 h-4 text-amber-600" />
                <span>Instant 24-Hour Quick Win:</span>
              </div>
              <p className="text-xs text-amber-950 font-medium leading-relaxed">
                {selectedAudience.quickWin}
              </p>
            </div>

            {/* Full 4-Step Checklist */}
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
              Comprehensive Action Checklist:
            </h4>
            <div className="space-y-3 mb-6">
              {selectedAudience.checklist.map((item, idx) => (
                <div key={idx} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/70 flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-[11px] shrink-0 mt-0.5">
                    {idx + 1}
                  </div>
                  <span className="text-xs font-medium text-slate-800 leading-snug">
                    {item}
                  </span>
                </div>
              ))}
            </div>

            <div className="pt-4 border-t border-slate-100 flex justify-end">
              <button
                onClick={() => setSelectedAudience(null)}
                className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold shadow-xs cursor-pointer"
              >
                Got It, Let's Implement!
              </button>
            </div>

          </div>
        </div>
      )}

    </section>
  );
}
