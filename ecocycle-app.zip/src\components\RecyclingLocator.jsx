import React, { useState, useEffect } from 'react';
import { 
  MapPin, 
  Search, 
  Phone, 
  Clock, 
  ExternalLink, 
  ShieldCheck, 
  PlusCircle, 
  X, 
  Filter, 
  CheckCircle, 
  Compass,
  AlertCircle,
  Building
} from 'lucide-react';
import { defaultRecyclingCenters } from '../data/recyclingCentersData';
import { getStoredCenters, saveStoredCenters } from '../utils/storage';

export default function RecyclingLocator() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMaterial, setSelectedMaterial] = useState('All');
  const [centers, setCenters] = useState(defaultRecyclingCenters);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedCenterForMap, setSelectedCenterForMap] = useState(null);

  // Form state for adding center
  const [newCenter, setNewCenter] = useState({
    name: '',
    city: '',
    state: '',
    pinCode: '',
    address: '',
    materials: '',
    hours: 'Mon - Fri: 9:00 AM - 5:00 PM',
    phone: '',
    website: '',
    type: 'Community Verified Drop-off'
  });
  const [addSuccessMsg, setAddSuccessMsg] = useState(false);

  // Load community centers from local storage
  useEffect(() => {
    const community = getStoredCenters();
    if (community && community.length > 0) {
      setCenters([...defaultRecyclingCenters, ...community]);
    }
  }, []);

  const materialsOptions = [
    'All',
    'PET Bottles (#1)',
    'HDPE Jugs (#2)',
    'Plastic Film',
    'Rigid Plastics (#5)',
    'Polystyrene',
    'E-Waste'
  ];

  // Filtering logic
  const filteredCenters = centers.filter((center) => {
    const term = searchTerm.toLowerCase().trim();
    const matchesSearch = 
      !term ||
      center.city.toLowerCase().includes(term) ||
      center.pinCode.toLowerCase().includes(term) ||
      center.name.toLowerCase().includes(term) ||
      center.address.toLowerCase().includes(term) ||
      (center.state && center.state.toLowerCase().includes(term));

    const matchesMaterial = 
      selectedMaterial === 'All' ||
      center.materials.some(m => m.toLowerCase().includes(selectedMaterial.toLowerCase().split(' ')[0]));

    return matchesSearch && matchesMaterial;
  });

  const handleAddCenterSubmit = (e) => {
    e.preventDefault();
    if (!newCenter.name || !newCenter.city || !newCenter.pinCode || !newCenter.address) {
      alert('Please fill out the required facility name, city, PIN code, and address.');
      return;
    }

    const createdCenter = {
      id: `community-${Date.now()}`,
      name: newCenter.name,
      city: newCenter.city,
      state: newCenter.state || 'Local Region',
      pinCode: newCenter.pinCode,
      address: newCenter.address,
      materials: newCenter.materials ? newCenter.materials.split(',').map(m => m.trim()) : ['PET Bottles (#1)', 'HDPE (#2)'],
      hours: newCenter.hours,
      phone: newCenter.phone || 'Contact on site',
      website: newCenter.website || '',
      type: newCenter.type,
      verified: true,
      isCommunityAdded: true
    };

    const existingCommunity = getStoredCenters();
    const updatedCommunity = [createdCenter, ...existingCommunity];
    saveStoredCenters(updatedCommunity);
    setCenters([createdCenter, ...centers]);
    setAddSuccessMsg(true);

    setTimeout(() => {
      setAddSuccessMsg(false);
      setIsAddModalOpen(false);
      setNewCenter({
        name: '',
        city: '',
        state: '',
        pinCode: '',
        address: '',
        materials: '',
        hours: 'Mon - Fri: 9:00 AM - 5:00 PM',
        phone: '',
        website: '',
        type: 'Community Verified Drop-off'
      });
    }, 1500);
  };

  return (
    <section id="locator" className="py-20 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wider mb-3">
            <MapPin className="w-3.5 h-3.5 text-emerald-600" />
            <span>Verified Recovery Infrastructure</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Find Nearby Plastic Recycling Centers
          </h2>
          <p className="mt-3 text-base text-slate-600">
            Search verified municipal Material Recovery Facilities (MRFs), specialized plastic film drop-off points, 
            and certified circular hubs by City or PIN / Postal code.
          </p>
        </div>

        {/* Search & Material Filter Bar */}
        <div className="bg-slate-50 rounded-3xl p-6 sm:p-8 border border-slate-200/80 mb-8 shadow-sm">
          <div className="flex flex-col md:flex-row items-stretch md:items-center gap-4">
            
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Enter City name or PIN / Postal Code (e.g. New York, London, Bengaluru, 11222, 560068)..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-3.5 rounded-2xl bg-white border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm text-slate-900 placeholder:text-slate-400 shadow-xs"
              />
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm('')}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-semibold text-slate-400 hover:text-slate-600 px-2 py-1 bg-slate-100 rounded"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Add Center Button */}
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-2xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs sm:text-sm shadow-md shadow-emerald-800/20 transition-all cursor-pointer shrink-0"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Submit Verified Center</span>
            </button>
          </div>

          {/* Material Filters */}
          <div className="flex flex-wrap items-center gap-2 mt-5 pt-4 border-t border-slate-200/70">
            <span className="text-xs font-bold text-slate-400 mr-2 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Acceptable Resins:
            </span>
            {materialsOptions.map((mat) => (
              <button
                key={mat}
                onClick={() => setSelectedMaterial(mat)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  selectedMaterial === mat
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:bg-slate-200 border border-slate-200'
                }`}
              >
                {mat}
              </button>
            ))}
          </div>
        </div>

        {/* Real Location Policy Notice */}
        <div className="mb-8 p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-200 text-emerald-950 text-xs flex items-center gap-3 text-left">
          <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
          <p>
            <strong>Reliability Commitment:</strong> All listings represent verified public municipal transfer depots, 
            certified Material Recovery Facilities (MRFs), or registered EPR collection partners. We never display fictional facilities.
          </p>
        </div>

        {/* Results Grid */}
        {filteredCenters.length === 0 ? (
          <div className="bg-slate-50 rounded-3xl p-12 text-center border border-slate-200">
            <MapPin className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h4 className="text-base font-bold text-slate-800">
              No collection centers found matching "{searchTerm}"
            </h4>
            <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
              Try searching by city name (e.g. New York, London, Bengaluru, Mumbai, Seattle) or a broader PIN code, or submit your local municipal center.
            </p>
            <div className="flex justify-center gap-3 mt-4">
              <button
                onClick={() => { setSearchTerm(''); setSelectedMaterial('All'); }}
                className="px-4 py-2 rounded-xl bg-slate-200 text-slate-700 text-xs font-semibold hover:bg-slate-300"
              >
                Reset Search
              </button>
              <button
                onClick={() => setIsAddModalOpen(true)}
                className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700"
              >
                + Add This Center
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCenters.map((center) => (
              <div
                key={center.id}
                className="bg-white rounded-3xl p-6 border border-slate-200 hover:border-emerald-300 hover:shadow-xl transition-all duration-300 flex flex-col justify-between text-left"
              >
                <div>
                  {/* Top: Facility Type & Verified Badge */}
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider truncate max-w-[190px]" title={center.type}>
                      {center.type}
                    </span>
                    <span className={`inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                      center.isCommunityAdded 
                        ? 'bg-teal-100 text-teal-800 border border-teal-200' 
                        : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                    }`}>
                      <ShieldCheck className="w-3 h-3" />
                      {center.isCommunityAdded ? 'Community Verified' : 'Official Verified'}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 leading-snug">
                    {center.name}
                  </h3>

                  {/* Address */}
                  <div className="flex items-start gap-2 text-xs text-slate-600 mt-2">
                    <MapPin className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>
                      {center.address}, {center.city}, {center.state} — <strong>{center.pinCode}</strong>
                    </span>
                  </div>

                  {/* Hours */}
                  <div className="flex items-center gap-2 text-xs text-slate-500 mt-2">
                    <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{center.hours}</span>
                  </div>

                  {/* Phone */}
                  {center.phone && (
                    <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                      <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{center.phone}</span>
                    </div>
                  )}

                  {/* Accepted Plastics */}
                  <div className="mt-4 pt-3 border-t border-slate-100">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5">
                      Accepted Plastic Streams:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {center.materials.map((m, idx) => (
                        <span key={idx} className="text-[10px] font-semibold bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded-md border border-emerald-100">
                          {m}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Bottom Actions */}
                <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between">
                  {center.website ? (
                    <a
                      href={center.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700 hover:text-emerald-900 hover:underline"
                    >
                      <span>Official Portal</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  ) : (
                    <span className="text-xs text-slate-400 italic">Municipal drop-off</span>
                  )}

                  <a
                    href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${center.name} ${center.address} ${center.city}`)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs font-semibold px-3 py-1.5 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-800 text-slate-700 rounded-lg transition-colors"
                  >
                    <Compass className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Directions</span>
                  </a>
                </div>

              </div>
            ))}
          </div>
        )}

      </div>

      {/* Modal: Add Verified Recycling Center */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto text-left relative">
            
            <button
              onClick={() => setIsAddModalOpen(false)}
              className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="pr-8 mb-5">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md">
                Community Contribution
              </span>
              <h3 className="text-xl font-extrabold text-slate-900 mt-1">
                Submit a Verified Recycling Center
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Add an authorized municipal, supermarket, or institutional drop-off point to assist local citizens.
              </p>
            </div>

            {addSuccessMsg ? (
              <div className="py-8 text-center bg-emerald-50 rounded-2xl border border-emerald-200 p-6">
                <CheckCircle className="w-12 h-12 text-emerald-600 mx-auto mb-2 animate-bounce" />
                <h4 className="text-base font-bold text-emerald-900">Center Added Successfully!</h4>
                <p className="text-xs text-emerald-700 mt-1">
                  Saved locally and displayed with a Community Verified badge.
                </p>
              </div>
            ) : (
              <form onSubmit={handleAddCenterSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Facility Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Metro West Recycling & Transfer Depot"
                    value={newCenter.name}
                    onChange={(e) => setNewCenter({ ...newCenter, name: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      City *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Austin"
                      value={newCenter.city}
                      onChange={(e) => setNewCenter({ ...newCenter, city: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      PIN / Postal Code *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. 78701"
                      value={newCenter.pinCode}
                      onChange={(e) => setNewCenter({ ...newCenter, pinCode: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Physical Street Address *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 104 Industrial Pkwy"
                    value={newCenter.address}
                    onChange={(e) => setNewCenter({ ...newCenter, address: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Accepted Plastics (comma separated)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. PET Bottles (#1), HDPE (#2), PP Containers (#5)"
                    value={newCenter.materials}
                    onChange={(e) => setNewCenter({ ...newCenter, materials: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Operating Hours
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Mon-Fri 8am-4pm"
                      value={newCenter.hours}
                      onChange={(e) => setNewCenter({ ...newCenter, hours: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Phone Number
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. +1 555-0199"
                      value={newCenter.phone}
                      onChange={(e) => setNewCenter({ ...newCenter, phone: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setIsAddModalOpen(false)}
                    className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md transition-all cursor-pointer"
                  >
                    Save & Publish Center
                  </button>
                </div>
              </form>
            )}

          </div>
        </div>
      )}

    </section>
  );
}
