import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import StatsBanner from './components/StatsBanner';
import PollutionAwareness from './components/PollutionAwareness';
import SmartSolutions from './components/SmartSolutions';
import PlasticCalculator from './components/PlasticCalculator';
import WasteSortingGuide from './components/WasteSortingGuide';
import EcoChallenge from './components/EcoChallenge';
import RecyclingLocator from './components/RecyclingLocator';
import ImpactDashboard from './components/ImpactDashboard';
import AboutAndAction from './components/AboutAndAction';
import Footer from './components/Footer';
import { getStoredChallenges, getStoredFootprint } from './utils/storage';

export default function App() {
  const [challenges, setChallenges] = useState({});
  const [footprint, setFootprint] = useState(null);

  useEffect(() => {
    setChallenges(getStoredChallenges());
    setFootprint(getStoredFootprint());
  }, []);

  const completedCount = Object.values(challenges).filter(Boolean).length;

  const handleChallengesUpdated = (newMap) => {
    setChallenges(newMap);
  };

  const handleFootprintSaved = (newFootprint) => {
    setFootprint(newFootprint);
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 font-sans antialiased selection:bg-emerald-200 selection:text-emerald-950">
      
      {/* Sticky Modern Navbar */}
      <Navbar completedChallengesCount={completedCount} />

      {/* Hero Section */}
      <main>
        <Hero />

        {/* Global Statistics Banner with Scientific Citations */}
        <StatsBanner />

        {/* Section 4: Plastic Pollution Awareness & Material Comparison */}
        <PollutionAwareness />

        {/* Section 5: Smart Recycling Solutions & Clean Tech */}
        <SmartSolutions />

        {/* Section 6: Plastic Footprint Calculator */}
        <PlasticCalculator onFootprintSaved={handleFootprintSaved} />

        {/* Section 7: Waste Sorting Guide */}
        <WasteSortingGuide />

        {/* Section 8: 7-Day Plastic-Free Challenge */}
        <EcoChallenge onChallengesUpdated={handleChallengesUpdated} />

        {/* Section 9: Recycling Center Locator */}
        <RecyclingLocator />

        {/* Section 10: Impact Dashboard */}
        <ImpactDashboard 
          footprintData={footprint} 
          challengesData={challenges} 
        />

        {/* Section 11: About Mission & Take Action Today */}
        <AboutAndAction />
      </main>

      {/* Footer & Global Resources */}
      <Footer />

    </div>
  );
}
