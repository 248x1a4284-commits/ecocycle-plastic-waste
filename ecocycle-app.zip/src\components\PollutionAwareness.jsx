import React, { useState } from 'react';
import { 
  Mountain, 
  Waves, 
  HeartPulse, 
  AlertTriangle, 
  Check, 
  X, 
  ChevronRight, 
  HelpCircle, 
  Sparkles,
  Layers
} from 'lucide-react';
import { pollutionFacts, plasticComparison } from '../data/awarenessData';

export default function PollutionAwareness() {
  const [activeTab, setActiveTab] = useState(pollutionFacts[0].id);
  const [selectedPlasticIndex, setSelectedPlasticIndex] = useState(0);

  const iconMap = {
    Mountain,
    Waves,
    HeartPulse,
    AlertTriangle
  };

  const currentFact = pollutionFacts.find(f => f.id === activeTab) || pollutionFacts[0];

  return (
    <section id="awareness" className="py-20 bg-slate-50 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wider mb-3">
            <AlertTriangle className="w-3.5 h-3.5 text-emerald-700" />
            <span>Ecological Reality Check</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            The True Cost of Plastic Pollution
          </h2>
          <p className="mt-3 text-base text-slate-600">
            From the Mariana Trench to mountain glaciers, plastic does not disappear—it fragments into microplastics 
            that permeate our soil, water, atmosphere, and biology.
          </p>
        </div>

        {/* Part 1: Interactive 4-Pillar Awareness Navigator */}
        <div className="bg-white rounded-3xl shadow-xl border border-slate-200/80 overflow-hidden mb-16">
          
          {/* Navigation Tabs */}
          <div className="grid grid-cols-2 md:grid-cols-4 border-b border-slate-100 bg-slate-50/60">
            {pollutionFacts.map((fact) => {
              const Icon = iconMap[fact.icon] || Mountain;
              const isActive = activeTab === fact.id;

              return (
                <button
                  key={fact.id}
                  onClick={() => setActiveTab(fact.id)}
                  className={`flex flex-col sm:flex-row items-center justify-center gap-2.5 py-4 px-3 sm:px-5 text-center sm:text-left transition-all border-b-2 cursor-pointer ${
                    isActive 
                      ? 'bg-white border-emerald-600 text-emerald-900 font-bold shadow-xs' 
                      : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-100/70 font-medium'
                  }`}
                >
                  <div className={`p-2 rounded-xl shrink-0 ${
                    isActive ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-200/70 text-slate-500'
                  }`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold leading-tight">{fact.title.split('&')[0]}</div>
                    <span className="text-[10px] text-slate-400 hidden sm:inline-block">{fact.badge}</span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Active Tab Content Area */}
          <div className="p-6 sm:p-10">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              
              {/* Textual & Data Column */}
              <div className="lg:col-span-7 space-y-5 text-left">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 text-slate-700 text-xs font-semibold">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                  <span>{currentFact.badge}</span>
                </div>

                <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 leading-tight">
                  {currentFact.title}
                </h3>

                <p className="text-base font-medium text-emerald-900/90 leading-relaxed bg-emerald-50/70 p-3.5 rounded-xl border border-emerald-100">
                  {currentFact.summary}
                </p>

                <p className="text-sm text-slate-600 leading-relaxed">
                  {currentFact.description}
                </p>

                {/* Key Statistics Callout */}
                <div className="space-y-2 pt-2">
                  <h5 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Documented Impact Metrics:
                  </h5>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {currentFact.keyStats.map((stat, idx) => (
                      <div key={idx} className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-200/60">
                        <ChevronRight className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span className="text-xs font-medium text-slate-700 leading-snug">{stat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Thematic Tags */}
                <div className="flex flex-wrap gap-2 pt-2">
                  {currentFact.tags.map(t => (
                    <span key={t} className="text-[11px] font-semibold bg-slate-100 text-slate-600 px-2.5 py-1 rounded-lg">
                      #{t}
                    </span>
                  ))}
                </div>

              </div>

              {/* Visual Showcase Column */}
              <div className="lg:col-span-5">
                <div className="relative rounded-2xl overflow-hidden shadow-lg border border-slate-200 group">
                  <img
                    src={currentFact.image}
                    alt={currentFact.title}
                    className="w-full h-72 sm:h-80 object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4 text-white text-left">
                    <span className="text-[11px] font-bold uppercase tracking-wider bg-emerald-600/90 px-2 py-0.5 rounded-md">
                      Environmental Ground Reality
                    </span>
                    <h4 className="text-base font-bold mt-1 text-white">
                      {currentFact.title}
                    </h4>
                    <p className="text-xs text-slate-200 mt-0.5 line-clamp-2">
                      {currentFact.summary}
                    </p>
                  </div>
                </div>
              </div>

            </div>
          </div>

        </div>

        {/* Part 2: Interactive Plastic Matrix: Biodegradable vs Recyclable vs Non-Recyclable */}
        <div className="mt-16">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-100 text-teal-800 text-xs font-bold uppercase tracking-wider mb-2">
              <Layers className="w-3.5 h-3.5 text-teal-700" />
              <span>Scientific Categorization</span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Biodegradable vs Recyclable vs Non-Recyclable
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-2">
              Understanding polymer behavior is critical: greenwashing and misleading labels cause massive contamination in municipal recycling streams.
            </p>
          </div>

          {/* Selector Tabs */}
          <div className="flex flex-wrap items-center justify-center gap-2 mb-8">
            {plasticComparison.map((item, idx) => (
              <button
                key={item.type}
                onClick={() => setSelectedPlasticIndex(idx)}
                className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                  selectedPlasticIndex === idx
                    ? 'bg-emerald-700 text-white shadow-md'
                    : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                {item.type}
              </button>
            ))}
          </div>

          {/* Matrix Card Detail */}
          {(() => {
            const item = plasticComparison[selectedPlasticIndex];
            return (
              <div className="bg-white rounded-3xl p-6 sm:p-10 shadow-lg border border-slate-200 text-left">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-100">
                  <div>
                    <span className={`inline-block text-xs font-bold px-3 py-1 rounded-full border ${item.badgeColor} mb-2`}>
                      {item.badge}
                    </span>
                    <h4 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                      {item.type}
                    </h4>
                    <p className="text-xs sm:text-sm text-slate-500 font-mono mt-0.5">
                      Resin Identifiers: {item.resinCode}
                    </p>
                  </div>

                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/70 shrink-0 max-w-sm">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                      Decomposition Horizon:
                    </span>
                    <div className="text-sm font-bold text-slate-800 mt-0.5">
                      {item.degradation}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-6">
                  {/* Left Column: Properties & Critical Disposal */}
                  <div className="space-y-4">
                    <div>
                      <h5 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">
                        Chemical & Material Nature:
                      </h5>
                      <p className="text-sm text-slate-700 leading-relaxed bg-slate-50 p-3.5 rounded-xl border border-slate-200/60">
                        {item.properties}
                      </p>
                    </div>

                    <div>
                      <h5 className="text-xs font-bold uppercase tracking-wider text-emerald-800 mb-1 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Crucial Disposal Rules:</span>
                      </h5>
                      <p className="text-xs text-slate-600 leading-relaxed bg-emerald-50/50 p-3.5 rounded-xl border border-emerald-100">
                        {item.disposalGuide}
                      </p>
                    </div>
                  </div>

                  {/* Right Column: Pros vs Cons */}
                  <div className="space-y-4">
                    {/* Advantages */}
                    <div>
                      <h5 className="text-xs font-bold uppercase tracking-wider text-emerald-700 mb-2 flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" />
                        <span>Environmental Advantages:</span>
                      </h5>
                      <ul className="space-y-2">
                        {item.pros.map((pro, i) => (
                          <li key={i} className="flex items-start gap-2 text-xs text-slate-700">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                            <span>{pro}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Limitations & Real-World Caveats */}
                    <div>
                      <h5 className="text-xs font-bold uppercase tracking-wider text-rose-700 mb-2 flex items-center gap-1">
                        <X className="w-3.5 h-3.5" />
                        <span>Limitations & Hazards:</span>
                      </h5>
                      <ul className="space-y-2">
                        {item.cons.map((con, i) => (
                          <li key={i} className="flex items-start gap-2 text-xs text-slate-700">
                            <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mt-1.5 shrink-0" />
                            <span>{con}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>

              </div>
            );
          })()}

        </div>

      </div>
    </section>
  );
}
