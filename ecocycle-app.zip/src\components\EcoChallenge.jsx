import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { 
  CheckCircle2, 
  Circle, 
  Trophy, 
  Sparkles, 
  Flame, 
  RotateCcw, 
  Droplets, 
  ShoppingBag, 
  PackageCheck, 
  Coffee, 
  Boxes, 
  Repeat, 
  MapPin,
  ChevronRight,
  Award
} from 'lucide-react';
import { challengeDays } from '../data/challengeData';
import { getStoredChallenges, saveStoredChallenges } from '../utils/storage';

export default function EcoChallenge({ onChallengesUpdated }) {
  const [completedMap, setCompletedMap] = useState({});
  const [justCompletedAll, setJustCompletedAll] = useState(false);

  const iconMap = {
    Droplets,
    ShoppingBag,
    PackageCheck,
    Coffee,
    Boxes,
    Repeat,
    MapPin
  };

  // Load from local storage
  useEffect(() => {
    const saved = getStoredChallenges();
    setCompletedMap(saved);
  }, []);

  const completedCount = Object.values(completedMap).filter(Boolean).length;
  const progressPercent = Math.round((completedCount / challengeDays.length) * 100);

  const triggerConfetti = () => {
    try {
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#10b981', '#064e3b', '#38bdf8', '#34d399', '#f59e0b']
      });
    } catch (e) {
      // safe fallback
    }
  };

  const toggleChallenge = (dayNum) => {
    const newMap = {
      ...completedMap,
      [dayNum]: !completedMap[dayNum]
    };
    setCompletedMap(newMap);
    saveStoredChallenges(newMap);

    if (onChallengesUpdated) {
      onChallengesUpdated(newMap);
    }

    if (!completedMap[dayNum]) {
      triggerConfetti();
      const count = Object.values(newMap).filter(Boolean).length;
      if (count === challengeDays.length) {
        setJustCompletedAll(true);
        try {
          confetti({
            particleCount: 150,
            spread: 100,
            origin: { y: 0.6 }
          });
        } catch (e) {}
      }
    }
  };

  const resetAllChallenges = () => {
    setCompletedMap({});
    saveStoredChallenges({});
    setJustCompletedAll(false);
    if (onChallengesUpdated) {
      onChallengesUpdated({});
    }
  };

  return (
    <section id="challenge" className="py-20 bg-gradient-to-b from-white via-emerald-50/40 to-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wider mb-3">
            <Flame className="w-3.5 h-3.5 text-emerald-600" />
            <span>Community Action</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            7-Day Plastic-Free Challenge
          </h2>
          <p className="mt-3 text-base text-slate-600">
            Build sustainable plastic-reduction habits in just one week. Mark each daily mission complete 
            to unlock your progress badge and sync directly with your personal impact dashboard.
          </p>
        </div>

        {/* Progress Tracker Card */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-200/80 mb-10 max-w-4xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 mb-6 border-b border-slate-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-lg shadow-xs">
                <Trophy className="w-6 h-6 text-emerald-600" />
              </div>
              <div className="text-left">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Your Challenge Progress
                </div>
                <div className="text-xl font-extrabold text-slate-900">
                  {completedCount} of {challengeDays.length} Days Completed
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-2xl font-extrabold text-emerald-700">
                {progressPercent}%
              </span>
              <button
                onClick={resetAllChallenges}
                className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-rose-600 font-medium px-3 py-1.5 rounded-lg border border-slate-200 hover:border-rose-200 transition-colors"
                title="Reset challenge progress"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Streak</span>
              </button>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-slate-100 h-3.5 rounded-full overflow-hidden p-0.5 border border-slate-200/80">
            <div
              className="bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 h-full rounded-full transition-all duration-500"
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          {/* Completion Celebration Message */}
          {completedCount === challengeDays.length && (
            <div className="mt-6 p-4 rounded-2xl bg-emerald-500 text-white flex items-center justify-between gap-4 animate-in fade-in duration-300 shadow-lg shadow-emerald-500/20 text-left">
              <div className="flex items-center gap-3">
                <Award className="w-8 h-8 text-yellow-300 shrink-0" />
                <div>
                  <h4 className="font-extrabold text-sm sm:text-base">
                    🎉 Outstanding Achievement! 7-Day Challenge Completed!
                  </h4>
                  <p className="text-xs text-emerald-100 mt-0.5">
                    You have successfully established the foundational habits of a plastic-conscious lifestyle.
                  </p>
                </div>
              </div>
              <button
                onClick={triggerConfetti}
                className="px-3.5 py-1.5 rounded-xl bg-white text-emerald-900 font-bold text-xs shadow-xs hover:bg-emerald-50 transition-colors shrink-0"
              >
                Celebrate! 🎊
              </button>
            </div>
          )}
        </div>

        {/* 7 Daily Challenge Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {challengeDays.map((c) => {
            const Icon = iconMap[c.icon] || Droplets;
            const isCompleted = !!completedMap[c.day];

            return (
              <div
                key={c.day}
                onClick={() => toggleChallenge(c.day)}
                className={`relative rounded-3xl p-6 border transition-all duration-300 cursor-pointer text-left flex flex-col justify-between ${
                  isCompleted
                    ? 'bg-emerald-50/80 border-emerald-300 shadow-md ring-1 ring-emerald-400'
                    : 'bg-white border-slate-200/80 hover:border-emerald-300 hover:shadow-lg'
                }`}
              >
                <div>
                  {/* Top: Day # & Status */}
                  <div className="flex items-center justify-between mb-4">
                    <span className={`text-xs font-extrabold px-3 py-1 rounded-full ${
                      isCompleted ? 'bg-emerald-200 text-emerald-900' : 'bg-slate-100 text-slate-600'
                    }`}>
                      Day {c.day} • {c.badge}
                    </span>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleChallenge(c.day);
                      }}
                      className="p-1 rounded-full text-slate-400 hover:text-emerald-600 transition-colors"
                      aria-label="Toggle challenge"
                    >
                      {isCompleted ? (
                        <CheckCircle2 className="w-6 h-6 text-emerald-600 fill-emerald-100" />
                      ) : (
                        <Circle className="w-6 h-6 text-slate-300 hover:text-emerald-500" />
                      )}
                    </button>
                  </div>

                  {/* Icon & Title */}
                  <div className="flex items-start gap-3 mb-3">
                    <div className={`p-2.5 rounded-2xl shrink-0 ${
                      isCompleted ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'
                    }`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <h3 className={`text-base font-bold leading-snug ${
                      isCompleted ? 'text-emerald-950 line-through opacity-85' : 'text-slate-900'
                    }`}>
                      {c.title}
                    </h3>
                  </div>

                  {/* Action Description */}
                  <p className="text-xs text-slate-600 leading-relaxed mb-4">
                    {c.action}
                  </p>

                  {/* Environmental Impact Tip */}
                  <div className="p-3 rounded-2xl bg-white/90 border border-slate-200/60 text-[11px] text-slate-600 mb-3">
                    <strong className="text-emerald-800">Impact: </strong>
                    {c.impactTip}
                  </div>
                </div>

                {/* Pro Tip */}
                <div className="pt-3 border-t border-slate-200/50 flex items-center justify-between text-[11px]">
                  <span className="text-slate-500 italic">
                    💡 {c.proTip}
                  </span>
                  <span className={`font-bold shrink-0 ml-2 ${isCompleted ? 'text-emerald-700' : 'text-slate-400'}`}>
                    {isCompleted ? 'Done' : 'Pending'}
                  </span>
                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
